import { createClient } from "@supabase/supabase-js"

// These would be environment variables in a real application
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || ""
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ""

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

export type Profile = {
  id: string
  username: string
  full_name: string
  avatar_url: string
  website: string
  tier: "listener" | "guild" | "therapist"
  created_at: string
}

export type Content = {
  id: string
  title: string
  description: string
  type: "audio" | "video"
  url: string
  thumbnail_url: string
  duration: number
  user_id: string
  created_at: string
  is_public: boolean
}

export type Message = {
  id: string
  sender_id: string
  receiver_id: string
  content: string
  created_at: string
  read: boolean
}

export type Appointment = {
  id: string
  client_id: string
  therapist_id: string
  title: string
  description: string
  start_time: string
  end_time: string
  platform: "zoom" | "google_meet" | "other"
  meeting_url: string
  status: "scheduled" | "completed" | "cancelled"
}

