import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardFooter } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { MapPin, Star, CheckCircle, Video, Users } from "lucide-react"

interface TherapistCardProps {
  therapist: {
    id: string
    name: string
    title: string
    avatar: string
    location: string
    specialties: string[]
    rating: number
    reviewCount: number
    verified: boolean
    featured: boolean
    online: boolean
    inPerson: boolean
    bio: string
    hourlyRate: number
  }
}

export function TherapistCard({ therapist }: TherapistCardProps) {
  return (
    <Card className={`overflow-hidden h-full flex flex-col ${therapist.featured ? "border-primary/50 shadow-md" : ""}`}>
      <div className="p-6">
        <div className="flex items-start gap-4">
          <Avatar className="h-16 w-16 border">
            <AvatarImage src={therapist.avatar} alt={therapist.name} />
            <AvatarFallback>{therapist.name.charAt(0)}</AvatarFallback>
          </Avatar>

          <div className="flex-1 space-y-1.5">
            <div className="flex items-center">
              <h3 className="font-semibold text-lg">{therapist.name}</h3>
              {therapist.verified && (
                <Badge variant="secondary" className="ml-2 gap-1">
                  <CheckCircle className="h-3 w-3" /> Verified
                </Badge>
              )}
              {therapist.featured && <Badge className="ml-2">Featured</Badge>}
            </div>

            <p className="text-muted-foreground">{therapist.title}</p>

            <div className="flex items-center text-sm">
              <MapPin className="h-3.5 w-3.5 mr-1 text-muted-foreground" />
              <span>{therapist.location}</span>
            </div>

            <div className="flex items-center">
              <div className="flex items-center">
                <Star className="h-4 w-4 text-yellow-400 fill-yellow-400" />
                <span className="ml-1 font-medium">{therapist.rating}</span>
                <span className="ml-1 text-muted-foreground">({therapist.reviewCount})</span>
              </div>

              <div className="flex ml-4 space-x-2">
                {therapist.online && (
                  <Badge variant="outline" className="text-xs gap-1">
                    <Video className="h-3 w-3" /> Online
                  </Badge>
                )}
                {therapist.inPerson && (
                  <Badge variant="outline" className="text-xs gap-1">
                    <Users className="h-3 w-3" /> In-Person
                  </Badge>
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="mt-4">
          <p className="text-sm line-clamp-3">{therapist.bio}</p>
        </div>

        <div className="mt-4 flex flex-wrap gap-1">
          {therapist.specialties.slice(0, 3).map((specialty) => (
            <Badge key={specialty} variant="secondary" className="font-normal">
              {specialty}
            </Badge>
          ))}
          {therapist.specialties.length > 3 && (
            <Badge variant="secondary" className="font-normal">
              +{therapist.specialties.length - 3} more
            </Badge>
          )}
        </div>
      </div>

      <CardFooter className="flex justify-between items-center border-t p-4 mt-auto">
        <div>
          <p className="font-semibold">£{therapist.hourlyRate}/hour</p>
        </div>

        <Button asChild>
          <Link href={`/therapists/${therapist.id}`}>View Profile</Link>
        </Button>
      </CardFooter>
    </Card>
  )
}

