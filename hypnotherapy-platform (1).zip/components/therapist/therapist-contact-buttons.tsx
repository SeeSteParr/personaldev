import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Mail, Phone, Globe, MessageSquare, Video } from "lucide-react"

interface TherapistContactButtonsProps {
  contact: {
    email: string
    phone: string
    website?: string
    whatsapp?: string
    zoom?: string
    socialMedia: {
      facebook?: string
      twitter?: string
      linkedin?: string
      instagram?: string
      youtube?: string
    }
  }
}

export function TherapistContactButtons({ contact }: TherapistContactButtonsProps) {
  return (
    <div className="space-y-3">
      <Button variant="outline" className="w-full justify-start" asChild>
        <Link href={`mailto:${contact.email}`}>
          <Mail className="mr-2 h-4 w-4" />
          Email
        </Link>
      </Button>

      <Button variant="outline" className="w-full justify-start" asChild>
        <Link href={`tel:${contact.phone.replace(/\s+/g, "")}`}>
          <Phone className="mr-2 h-4 w-4" />
          Call
        </Link>
      </Button>

      {contact.website && (
        <Button variant="outline" className="w-full justify-start" asChild>
          <Link href={contact.website} target="_blank" rel="noopener noreferrer">
            <Globe className="mr-2 h-4 w-4" />
            Website
          </Link>
        </Button>
      )}

      {contact.whatsapp && (
        <Button variant="outline" className="w-full justify-start" asChild>
          <Link
            href={`https://wa.me/${contact.whatsapp.replace(/\s+/g, "").replace(/^\+/, "")}`}
            target="_blank"
            rel="noopener noreferrer"
          >
            <MessageSquare className="mr-2 h-4 w-4" />
            WhatsApp
          </Link>
        </Button>
      )}

      {contact.zoom && (
        <Button variant="outline" className="w-full justify-start" asChild>
          <Link href={`https://zoom.us/j/${contact.zoom}`} target="_blank" rel="noopener noreferrer">
            <Video className="mr-2 h-4 w-4" />
            Zoom
          </Link>
        </Button>
      )}
    </div>
  )
}

