"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Star, ThumbsUp } from "lucide-react"

// Mock reviews data
const mockReviews = [
  {
    id: "review1",
    therapistId: "therapist1",
    user: {
      name: "Michael P.",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    rating: 5,
    date: "2023-10-15",
    title: "Life-changing experience",
    content:
      "Dr. Johnson helped me overcome my anxiety that I've struggled with for years. Her approach is professional yet compassionate. After just a few sessions, I noticed significant improvements in my daily life. Highly recommended!",
    helpfulCount: 12,
  },
  {
    id: "review2",
    therapistId: "therapist1",
    user: {
      name: "Jennifer L.",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    rating: 4,
    date: "2023-09-22",
    title: "Very effective for stress management",
    content:
      "I was skeptical about hypnotherapy at first, but Dr. Johnson made me feel comfortable and explained everything clearly. The techniques she taught me for managing stress have been invaluable. I only wish I had found her sooner.",
    helpfulCount: 8,
  },
  {
    id: "review3",
    therapistId: "therapist1",
    user: {
      name: "Robert K.",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    rating: 5,
    date: "2023-11-03",
    title: "Helped me quit smoking",
    content:
      "After trying everything to quit smoking, I decided to give hypnotherapy a try. Dr. Johnson's approach was different from anything I'd experienced before. It's been 3 months now and I haven't touched a cigarette. Her methods really work!",
    helpfulCount: 15,
  },
]

interface TherapistReviewsProps {
  therapistId: string
}

export function TherapistReviews({ therapistId }: TherapistReviewsProps) {
  const [helpfulReviews, setHelpfulReviews] = useState<string[]>([])

  // Filter reviews for this therapist
  const reviews = mockReviews.filter((review) => review.therapistId === therapistId)

  const handleMarkHelpful = (reviewId: string) => {
    if (helpfulReviews.includes(reviewId)) {
      setHelpfulReviews(helpfulReviews.filter((id) => id !== reviewId))
    } else {
      setHelpfulReviews([...helpfulReviews, reviewId])
    }
  }

  // Calculate average rating
  const averageRating = reviews.reduce((acc, review) => acc + review.rating, 0) / reviews.length

  // Count ratings by star
  const ratingCounts = {
    5: reviews.filter((r) => r.rating === 5).length,
    4: reviews.filter((r) => r.rating === 4).length,
    3: reviews.filter((r) => r.rating === 3).length,
    2: reviews.filter((r) => r.rating === 2).length,
    1: reviews.filter((r) => r.rating === 1).length,
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Client Reviews</CardTitle>
          <CardDescription>See what others are saying about this therapist</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row gap-6">
            <div className="md:w-1/3 flex flex-col items-center justify-center p-4 bg-muted/50 rounded-md">
              <div className="text-5xl font-bold">{averageRating.toFixed(1)}</div>
              <div className="flex mt-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star
                    key={star}
                    className={`h-5 w-5 ${
                      star <= Math.round(averageRating) ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
                    }`}
                  />
                ))}
              </div>
              <p className="text-sm text-muted-foreground mt-2">Based on {reviews.length} reviews</p>
            </div>

            <div className="md:w-2/3 space-y-2">
              {[5, 4, 3, 2, 1].map((star) => (
                <div key={star} className="flex items-center">
                  <div className="w-12 text-sm">{star} stars</div>
                  <div className="w-full mx-2 h-2 bg-muted rounded-full overflow-hidden">
                    <div
                      className="h-full bg-yellow-400"
                      style={{
                        width: `${reviews.length ? (ratingCounts[star as keyof typeof ratingCounts] / reviews.length) * 100 : 0}%`,
                      }}
                    />
                  </div>
                  <div className="w-8 text-sm text-right">{ratingCounts[star as keyof typeof ratingCounts]}</div>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-4">
        {reviews.map((review) => (
          <Card key={review.id}>
            <CardContent className="pt-6">
              <div className="flex items-start justify-between">
                <div className="flex items-center">
                  <Avatar className="h-10 w-10 mr-3">
                    <AvatarImage src={review.user.avatar} alt={review.user.name} />
                    <AvatarFallback>{review.user.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium">{review.user.name}</p>
                    <p className="text-sm text-muted-foreground">{review.date}</p>
                  </div>
                </div>
                <div className="flex">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star
                      key={star}
                      className={`h-4 w-4 ${
                        star <= review.rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
                      }`}
                    />
                  ))}
                </div>
              </div>

              <div className="mt-4">
                <h4 className="font-medium">{review.title}</h4>
                <p className="mt-2">{review.content}</p>
              </div>

              <div className="mt-4 flex justify-between items-center">
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-muted-foreground"
                  onClick={() => handleMarkHelpful(review.id)}
                >
                  <ThumbsUp
                    className={`mr-1 h-4 w-4 ${helpfulReviews.includes(review.id) ? "fill-current text-primary" : ""}`}
                  />
                  Helpful ({helpfulReviews.includes(review.id) ? review.helpfulCount + 1 : review.helpfulCount})
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="text-center">
        <Button variant="outline">Write a Review</Button>
      </div>
    </div>
  )
}

