import { Badge } from "@/components/ui/badge"

interface TherapistAvailabilityProps {
  availability: {
    monday: string[]
    tuesday: string[]
    wednesday: string[]
    thursday: string[]
    friday: string[]
    saturday: string[]
    sunday: string[]
  }
}

export function TherapistAvailability({ availability }: TherapistAvailabilityProps) {
  const days = [
    { name: "Monday", slots: availability.monday },
    { name: "Tuesday", slots: availability.tuesday },
    { name: "Wednesday", slots: availability.wednesday },
    { name: "Thursday", slots: availability.thursday },
    { name: "Friday", slots: availability.friday },
    { name: "Saturday", slots: availability.saturday },
    { name: "Sunday", slots: availability.sunday },
  ]

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {days.map((day) => (
        <div key={day.name} className="p-3 border rounded-md">
          <p className="font-medium">{day.name}</p>
          <div className="mt-2">
            {day.slots.length > 0 ? (
              day.slots.map((slot, index) => (
                <Badge key={index} variant="outline" className="mr-2 mt-1">
                  {slot}
                </Badge>
              ))
            ) : (
              <p className="text-sm text-muted-foreground">Not available</p>
            )}
          </div>
        </div>
      ))}
    </div>
  )
}

