import { Check, X } from "lucide-react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

interface UpgradeBenefitsTableProps {
  currentTier: string
}

export function UpgradeBenefitsTable({ currentTier }: UpgradeBenefitsTableProps) {
  const benefits = [
    {
      name: "Access to free hypnotherapy sessions",
      listener: true,
      guild: true,
      therapist: true,
    },
    {
      name: "Browse the store",
      listener: true,
      guild: true,
      therapist: true,
    },
    {
      name: "Create a basic profile",
      listener: true,
      guild: true,
      therapist: true,
    },
    {
      name: "Book sessions with therapists",
      listener: true,
      guild: true,
      therapist: true,
    },
    {
      name: "Complete hypnotherapy course",
      listener: false,
      guild: true,
      therapist: true,
    },
    {
      name: "Guild membership",
      listener: false,
      guild: true,
      therapist: true,
    },
    {
      name: "Upload and share audio content",
      listener: false,
      guild: true,
      therapist: true,
    },
    {
      name: "Community forum access",
      listener: false,
      guild: true,
      therapist: true,
    },
    {
      name: "Dedicated therapist profile page",
      listener: false,
      guild: false,
      therapist: true,
    },
    {
      name: "Professional certification",
      listener: false,
      guild: false,
      therapist: true,
    },
    {
      name: "Client booking system",
      listener: false,
      guild: false,
      therapist: true,
    },
    {
      name: "Upload and promote video content",
      listener: false,
      guild: false,
      therapist: true,
    },
    {
      name: "Featured in therapist directory",
      listener: false,
      guild: false,
      therapist: true,
    },
  ]

  return (
    <div className="overflow-auto">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-[300px]">Feature</TableHead>
            <TableHead className="text-center">Listener</TableHead>
            <TableHead className="text-center">Guild Member</TableHead>
            <TableHead className="text-center">Certified Therapist</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {benefits.map((benefit, index) => (
            <TableRow key={index}>
              <TableCell className="font-medium">{benefit.name}</TableCell>
              <TableCell className="text-center">
                {benefit.listener ? (
                  <Check className="h-4 w-4 text-green-500 mx-auto" />
                ) : (
                  <X className="h-4 w-4 text-muted-foreground mx-auto" />
                )}
              </TableCell>
              <TableCell className={`text-center ${currentTier === "listener" ? "bg-primary/5" : ""}`}>
                {benefit.guild ? (
                  <Check className="h-4 w-4 text-green-500 mx-auto" />
                ) : (
                  <X className="h-4 w-4 text-muted-foreground mx-auto" />
                )}
              </TableCell>
              <TableCell className={`text-center ${currentTier !== "therapist" ? "bg-primary/5" : ""}`}>
                {benefit.therapist ? (
                  <Check className="h-4 w-4 text-green-500 mx-auto" />
                ) : (
                  <X className="h-4 w-4 text-muted-foreground mx-auto" />
                )}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

