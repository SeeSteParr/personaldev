import { Card, CardContent } from "@/components/ui/card"
import type { ReactNode } from "react"

interface UpgradeFeatureCardProps {
  icon: ReactNode
  title: string
  description: string
}

export function UpgradeFeatureCard({ icon, title, description }: UpgradeFeatureCardProps) {
  return (
    <Card>
      <CardContent className="pt-6">
        <div className="flex flex-col items-center text-center space-y-3">
          <div className="p-3 bg-primary/10 rounded-full">{icon}</div>
          <h3 className="text-lg font-medium">{title}</h3>
          <p className="text-sm text-muted-foreground">{description}</p>
        </div>
      </CardContent>
    </Card>
  )
}

