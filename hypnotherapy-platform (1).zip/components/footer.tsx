import Link from "next/link"

export function Footer() {
  return (
    <footer className="w-full py-6 bg-background border-t">
      <div className="container px-4 md:px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Mind Mastery</h3>
            <p className="text-sm text-gray-500">
              Transform your mind with hypnotherapy, NLP, and personal development.
            </p>
          </div>
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="text-sm text-gray-500 hover:text-primary">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/store" className="text-sm text-gray-500 hover:text-primary">
                  Store
                </Link>
              </li>
              <li>
                <Link href="/courses" className="text-sm text-gray-500 hover:text-primary">
                  Courses
                </Link>
              </li>
              <li>
                <Link href="/therapists" className="text-sm text-gray-500 hover:text-primary">
                  Therapists
                </Link>
              </li>
            </ul>
          </div>
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Membership</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/register" className="text-sm text-gray-500 hover:text-primary">
                  Sign Up
                </Link>
              </li>
              <li>
                <Link href="/login" className="text-sm text-gray-500 hover:text-primary">
                  Log In
                </Link>
              </li>
              <li>
                <Link href="/pricing" className="text-sm text-gray-500 hover:text-primary">
                  Pricing
                </Link>
              </li>
              <li>
                <Link href="/guild" className="text-sm text-gray-500 hover:text-primary">
                  Guild Membership
                </Link>
              </li>
            </ul>
          </div>
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Legal</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/privacy" className="text-sm text-gray-500 hover:text-primary">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link href="/terms" className="text-sm text-gray-500 hover:text-primary">
                  Terms of Service
                </Link>
              </li>
              <li>
                <Link href="/cookies" className="text-sm text-gray-500 hover:text-primary">
                  Cookie Policy
                </Link>
              </li>
            </ul>
          </div>
        </div>
        <div className="mt-8 border-t pt-4">
          <p className="text-sm text-gray-500 text-center">
            © {new Date().getFullYear()} Mind Mastery. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  )
}

