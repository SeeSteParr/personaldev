import { RadioGroupItem } from "@/components/ui/radio-group"
import { Check } from "lucide-react"
import { cn } from "@/lib/utils"

interface SubscriptionTierCardProps {
  id: string
  name: string
  price: string
  period?: string
  description: string
  features: string[]
  selected?: boolean
  highlighted?: boolean
}

export function SubscriptionTierCard({
  id,
  name,
  price,
  period,
  description,
  features,
  selected = false,
  highlighted = false,
}: SubscriptionTierCardProps) {
  return (
    <label
      htmlFor={id}
      className={cn(
        "relative block cursor-pointer rounded-lg border p-6 transition-all",
        selected && "border-primary ring-2 ring-primary",
        highlighted && !selected && "border-primary/50",
        !selected && !highlighted && "hover:border-primary/50",
      )}
    >
      <RadioGroupItem value={id} id={id} className="sr-only" />

      {highlighted && (
        <div className="absolute -top-3 left-0 right-0 flex justify-center">
          <span className="bg-primary text-primary-foreground text-xs font-medium px-3 py-1 rounded-full">
            Recommended
          </span>
        </div>
      )}

      <div className="mb-4">
        <h3 className="text-lg font-semibold">{name}</h3>
        <p className="text-sm text-muted-foreground">{description}</p>
      </div>

      <div className="mb-4">
        <span className="text-2xl font-bold">{price}</span>
        {period && <span className="text-muted-foreground ml-1">{period}</span>}
      </div>

      <ul className="space-y-2 text-sm">
        {features.map((feature, index) => (
          <li key={index} className="flex items-center">
            <Check className="h-4 w-4 text-primary mr-2 flex-shrink-0" />
            <span>{feature}</span>
          </li>
        ))}
      </ul>
    </label>
  )
}

