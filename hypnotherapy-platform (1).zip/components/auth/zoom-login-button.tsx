import { Button } from "@/components/ui/button"
import { Video } from "lucide-react"

interface ZoomLoginButtonProps {
  onClick: () => void
  disabled?: boolean
  action?: string
}

export function ZoomLoginButton({ onClick, disabled = false, action = "Sign in" }: ZoomLoginButtonProps) {
  return (
    <Button
      variant="outline"
      className="w-full bg-blue-50 hover:bg-blue-100 border-blue-200"
      onClick={onClick}
      disabled={disabled}
    >
      <Video className="mr-2 h-4 w-4 text-blue-600" />
      {action} with Zoom
    </Button>
  )
}

