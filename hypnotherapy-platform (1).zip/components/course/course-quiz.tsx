"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Progress } from "@/components/ui/progress"
import { CheckCircle, XCircle } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"

interface Question {
  id: string
  question: string
  options: string[]
  correctAnswer: string
}

interface CourseQuizProps {
  questions: Question[]
  onComplete: () => void
}

export function CourseQuiz({ questions, onComplete }: CourseQuizProps) {
  const { toast } = useToast()
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, string>>({})
  const [showResults, setShowResults] = useState(false)
  const [score, setScore] = useState(0)

  const handleAnswerSelect = (answer: string) => {
    setSelectedAnswers({
      ...selectedAnswers,
      [questions[currentQuestion].id]: answer,
    })
  }

  const handleNextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1)
    } else {
      // Calculate score
      let correctCount = 0
      questions.forEach((question) => {
        if (selectedAnswers[question.id] === question.correctAnswer) {
          correctCount++
        }
      })

      const finalScore = Math.round((correctCount / questions.length) * 100)
      setScore(finalScore)
      setShowResults(true)

      if (finalScore >= 70) {
        toast({
          title: "Quiz Completed",
          description: `You scored ${finalScore}%. You have passed this quiz!`,
        })
      } else {
        toast({
          title: "Quiz Completed",
          description: `You scored ${finalScore}%. You need 70% to pass. Try again!`,
          variant: "destructive",
        })
      }
    }
  }

  const handlePreviousQuestion = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1)
    }
  }

  const handleRetakeQuiz = () => {
    setCurrentQuestion(0)
    setSelectedAnswers({})
    setShowResults(false)
    setScore(0)
  }

  const handleCompleteQuiz = () => {
    if (score >= 70) {
      onComplete()
    } else {
      toast({
        title: "Cannot Complete",
        description: "You need to score at least 70% to complete this quiz.",
        variant: "destructive",
      })
    }
  }

  const currentQuestionData = questions[currentQuestion]
  const progress = ((currentQuestion + 1) / questions.length) * 100

  if (showResults) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Quiz Results</CardTitle>
          <CardDescription>You scored {score}% on this quiz</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Your Score</span>
                <span>{score}%</span>
              </div>
              <Progress value={score} className="h-2" />
              <p className="text-sm text-muted-foreground mt-2">
                {score >= 70 ? "Congratulations! You passed the quiz." : "You need 70% to pass this quiz."}
              </p>
            </div>

            <div className="space-y-4">
              <h3 className="font-medium">Question Review</h3>
              {questions.map((question, index) => (
                <div key={question.id} className="border rounded-md p-4">
                  <div className="flex items-start">
                    <div className="mr-2">
                      {selectedAnswers[question.id] === question.correctAnswer ? (
                        <CheckCircle className="h-5 w-5 text-green-500" />
                      ) : (
                        <XCircle className="h-5 w-5 text-red-500" />
                      )}
                    </div>
                    <div>
                      <p className="font-medium">
                        Question {index + 1}: {question.question}
                      </p>
                      <p className="text-sm mt-1">
                        <span className="text-muted-foreground">Your answer: </span>
                        <span
                          className={
                            selectedAnswers[question.id] === question.correctAnswer ? "text-green-600" : "text-red-600"
                          }
                        >
                          {selectedAnswers[question.id] || "Not answered"}
                        </span>
                      </p>
                      {selectedAnswers[question.id] !== question.correctAnswer && (
                        <p className="text-sm mt-1">
                          <span className="text-muted-foreground">Correct answer: </span>
                          <span className="text-green-600">{question.correctAnswer}</span>
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline" onClick={handleRetakeQuiz}>
            Retake Quiz
          </Button>
          <Button onClick={handleCompleteQuiz}>{score >= 70 ? "Complete and Continue" : "Try Again"}</Button>
        </CardFooter>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>
          Quiz: Question {currentQuestion + 1} of {questions.length}
        </CardTitle>
        <CardDescription>Select the best answer for each question</CardDescription>
        <Progress value={progress} className="h-2 mt-2" />
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <h3 className="font-medium text-lg">{currentQuestionData.question}</h3>

          <RadioGroup value={selectedAnswers[currentQuestionData.id] || ""} onValueChange={handleAnswerSelect}>
            {currentQuestionData.options.map((option, index) => (
              <div key={index} className="flex items-center space-x-2 border rounded-md p-3 hover:bg-muted/50">
                <RadioGroupItem value={option} id={`option-${index}`} />
                <Label htmlFor={`option-${index}`} className="flex-1 cursor-pointer">
                  {option}
                </Label>
              </div>
            ))}
          </RadioGroup>
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button variant="outline" onClick={handlePreviousQuestion} disabled={currentQuestion === 0}>
          Previous
        </Button>
        <Button onClick={handleNextQuestion} disabled={!selectedAnswers[currentQuestionData.id]}>
          {currentQuestion < questions.length - 1 ? "Next" : "Finish Quiz"}
        </Button>
      </CardFooter>
    </Card>
  )
}

