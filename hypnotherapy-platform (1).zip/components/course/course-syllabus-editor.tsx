"use client"

import { useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Trash, Plus } from "lucide-react"

interface Lesson {
  title: string
  type: string
  duration: string
}

interface Module {
  title: string
  lessons: Lesson[]
}

interface CourseSyllabusEditorProps {
  syllabus: Module[]
  onChange: (syllabus: Module[]) => void
}

export function CourseSyllabusEditor({ syllabus, onChange }: CourseSyllabusEditorProps) {
  const handleModuleChange = useCallback(
    (moduleIndex: number, field: string, value: string) => {
      const newSyllabus = [...syllabus]
      newSyllabus[moduleIndex] = { ...newSyllabus[moduleIndex], [field]: value }
      onChange(newSyllabus)
    },
    [syllabus, onChange],
  )

  const handleAddModule = useCallback(() => {
    const newSyllabus = [...syllabus, { title: `Module ${syllabus.length + 1}`, lessons: [] }]
    onChange(newSyllabus)
  }, [syllabus, onChange])

  const handleRemoveModule = useCallback(
    (moduleIndex: number) => {
      const newSyllabus = [...syllabus]
      newSyllabus.splice(moduleIndex, 1)
      onChange(newSyllabus)
    },
    [syllabus, onChange],
  )

  const handleLessonChange = useCallback(
    (moduleIndex: number, lessonIndex: number, field: string, value: string) => {
      const newSyllabus = [...syllabus]
      newSyllabus[moduleIndex].lessons[lessonIndex] = {
        ...newSyllabus[moduleIndex].lessons[lessonIndex],
        [field]: value,
      }
      onChange(newSyllabus)
    },
    [syllabus, onChange],
  )

  const handleAddLesson = useCallback(
    (moduleIndex: number) => {
      const newSyllabus = [...syllabus]
      newSyllabus[moduleIndex].lessons = [
        ...newSyllabus[moduleIndex].lessons,
        { title: `Lesson ${newSyllabus[moduleIndex].lessons.length + 1}`, type: "video", duration: "30 min" },
      ]
      onChange(newSyllabus)
    },
    [syllabus, onChange],
  )

  const handleRemoveLesson = useCallback(
    (moduleIndex: number, lessonIndex: number) => {
      const newSyllabus = [...syllabus]
      newSyllabus[moduleIndex].lessons.splice(lessonIndex, 1)
      onChange(newSyllabus)
    },
    [syllabus, onChange],
  )

  return (
    <div className="space-y-4">
      {syllabus.map((module, moduleIndex) => (
        <div key={moduleIndex} className="border rounded-md p-4">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium">Module {moduleIndex + 1}</h3>
            <Button variant="ghost" size="icon" onClick={() => handleRemoveModule(moduleIndex)}>
              <Trash className="h-4 w-4" />
            </Button>
          </div>
          <div className="space-y-2">
            <Label htmlFor={`module-title-${moduleIndex}`}>Module Title</Label>
            <Input
              type="text"
              id={`module-title-${moduleIndex}`}
              value={module.title}
              onChange={(e) => handleModuleChange(moduleIndex, "title", e.target.value)}
            />
          </div>
          <div className="space-y-2 mt-4">
            <h4 className="text-md font-medium">Lessons</h4>
            {module.lessons.map((lesson, lessonIndex) => (
              <div key={lessonIndex} className="border rounded-md p-3">
                <div className="flex items-center justify-between mb-2">
                  <h5 className="text-sm font-medium">Lesson {lessonIndex + 1}</h5>
                  <Button variant="ghost" size="icon" onClick={() => handleRemoveLesson(moduleIndex, lessonIndex)}>
                    <Trash className="h-4 w-4" />
                  </Button>
                </div>
                <div className="space-y-1">
                  <Label htmlFor={`lesson-title-${moduleIndex}-${lessonIndex}`}>Lesson Title</Label>
                  <Input
                    type="text"
                    id={`lesson-title-${moduleIndex}-${lessonIndex}`}
                    value={lesson.title}
                    onChange={(e) => handleLessonChange(moduleIndex, lessonIndex, "title", e.target.value)}
                  />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mt-2">
                  <div>
                    <Label htmlFor={`lesson-type-${moduleIndex}-${lessonIndex}`}>Lesson Type</Label>
                    <Select
                      value={lesson.type}
                      onValueChange={(value) => handleLessonChange(moduleIndex, lessonIndex, "type", value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="video">Video</SelectItem>
                        <SelectItem value="quiz">Quiz</SelectItem>
                        <SelectItem value="assignment">Assignment</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor={`lesson-duration-${moduleIndex}-${lessonIndex}`}>Lesson Duration</Label>
                    <Input
                      type="text"
                      id={`lesson-duration-${moduleIndex}-${lessonIndex}`}
                      value={lesson.duration}
                      onChange={(e) => handleLessonChange(moduleIndex, lessonIndex, "duration", e.target.value)}
                    />
                  </div>
                </div>
              </div>
            ))}
            <Button variant="outline" size="sm" onClick={() => handleAddLesson(moduleIndex)}>
              <Plus className="h-4 w-4 mr-1" />
              Add Lesson
            </Button>
          </div>
        </div>
      ))}
      <Button variant="outline" onClick={handleAddModule}>
        <Plus className="h-4 w-4 mr-1" />
        Add Module
      </Button>
    </div>
  )
}

