"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { ChevronLeft, Play, FileText, CheckCircle, Menu } from "lucide-react"
import { cn } from "@/lib/utils"

interface CourseSidebarProps {
  course: any
  currentModule: number
  currentLesson: number
  setCurrentModule: (moduleIndex: number) => void
  setCurrentLesson: (lessonIndex: number) => void
}

export function CourseSidebar({
  course,
  currentModule,
  currentLesson,
  setCurrentModule,
  setCurrentLesson,
}: CourseSidebarProps) {
  const [isOpen, setIsOpen] = useState(true)

  const toggleSidebar = () => {
    setIsOpen(!isOpen)
  }

  const handleLessonClick = (moduleIndex: number, lessonIndex: number) => {
    setCurrentModule(moduleIndex)
    setCurrentLesson(lessonIndex)
  }

  return (
    <div
      className={cn("bg-muted/40 border-r relative transition-all duration-300 ease-in-out", isOpen ? "w-80" : "w-0")}
    >
      <div className="absolute -right-4 top-4 z-10">
        <Button
          variant="outline"
          size="icon"
          className="rounded-full h-8 w-8 bg-background shadow-md"
          onClick={toggleSidebar}
        >
          {isOpen ? <ChevronLeft className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
        </Button>
      </div>

      {isOpen && (
        <div className="h-full flex flex-col">
          <div className="p-4 border-b">
            <h2 className="font-semibold truncate">{course.title}</h2>
            <p className="text-sm text-muted-foreground truncate">{course.instructor}</p>
          </div>

          <ScrollArea className="flex-1">
            <div className="p-4">
              <Accordion type="multiple" defaultValue={[`module-${currentModule}`]} className="w-full">
                {course.syllabus.map((module: any, moduleIndex: number) => (
                  <AccordionItem key={module.id} value={`module-${moduleIndex}`}>
                    <AccordionTrigger className="text-sm hover:no-underline">
                      <span className="text-left">
                        Module {moduleIndex + 1}: {module.title}
                      </span>
                    </AccordionTrigger>
                    <AccordionContent>
                      <div className="pl-2 space-y-1">
                        {module.lessons.map((lesson: any, lessonIndex: number) => (
                          <Button
                            key={lesson.id}
                            variant="ghost"
                            className={cn(
                              "w-full justify-start text-left text-sm h-auto py-2",
                              moduleIndex === currentModule && lessonIndex === currentLesson
                                ? "bg-muted font-medium"
                                : "font-normal",
                            )}
                            onClick={() => handleLessonClick(moduleIndex, lessonIndex)}
                          >
                            <div className="flex items-start">
                              <div className="mr-2 mt-0.5">
                                {lesson.type === "video" && <Play className="h-4 w-4" />}
                                {lesson.type === "quiz" && <FileText className="h-4 w-4" />}
                                {lesson.type === "assignment" && <FileText className="h-4 w-4" />}
                              </div>
                              <div className="flex-1">
                                <div className="flex items-center">
                                  <span className="truncate">{lesson.title}</span>
                                  {lesson.completed && <CheckCircle className="h-3 w-3 text-green-500 ml-2 shrink-0" />}
                                </div>
                                <div className="text-xs text-muted-foreground">
                                  {lesson.duration} • {lesson.type}
                                </div>
                              </div>
                            </div>
                          </Button>
                        ))}
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </div>
          </ScrollArea>
        </div>
      )}
    </div>
  )
}

