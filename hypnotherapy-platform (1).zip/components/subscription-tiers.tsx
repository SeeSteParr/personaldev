import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Check } from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function SubscriptionTiers() {
  const tiers = [
    {
      name: "Listener",
      price: "Free",
      description: "Basic access for listeners and clients",
      features: [
        "Access to free hypnotherapy sessions",
        "Browse the store",
        "Create a basic profile",
        "Book sessions with therapists",
      ],
      cta: "Sign Up",
      href: "/register",
      highlighted: false,
    },
    {
      name: "Guild Member",
      price: "£10",
      period: "per month",
      description: "For aspiring hypnotherapists and NLP practitioners",
      features: [
        "All Listener features",
        "Complete hypnotherapy course",
        "Guild of International Hypnotherapeutic Knights membership",
        "Upload and share audio content",
        "Community forum access",
      ],
      cta: "Subscribe",
      href: "/register?tier=guild",
      highlighted: true,
    },
    {
      name: "Certified Therapist",
      price: "£49",
      period: "per month",
      description: "For qualified therapists seeking to grow their practice",
      features: [
        "All Guild Member features",
        "Dedicated therapist profile page",
        "Professional appraisal and certification",
        "Client booking system",
        "Upload and promote audio and video content",
        "Featured in therapist directory",
      ],
      cta: "Get Certified",
      href: "/register?tier=therapist",
      highlighted: false,
    },
  ]

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
      {tiers.map((tier) => (
        <Card
          key={tier.name}
          className={`flex flex-col ${tier.highlighted ? "border-primary shadow-lg shadow-primary/20" : ""}`}
        >
          <CardHeader>
            <CardTitle>{tier.name}</CardTitle>
            <CardDescription>{tier.description}</CardDescription>
            <div className="mt-4">
              <span className="text-3xl font-bold">{tier.price}</span>
              {tier.period && <span className="text-gray-500 ml-1">{tier.period}</span>}
            </div>
          </CardHeader>
          <CardContent className="flex-1">
            <ul className="space-y-2">
              {tier.features.map((feature) => (
                <li key={feature} className="flex items-center">
                  <Check className="h-4 w-4 text-primary mr-2" />
                  <span>{feature}</span>
                </li>
              ))}
            </ul>
          </CardContent>
          <CardFooter>
            <Button asChild className="w-full" variant={tier.highlighted ? "default" : "outline"}>
              <Link href={tier.href}>{tier.cta}</Link>
            </Button>
          </CardFooter>
        </Card>
      ))}
    </div>
  )
}

