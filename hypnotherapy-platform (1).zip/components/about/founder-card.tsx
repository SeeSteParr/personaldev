import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Linkedin, Twitter } from "lucide-react"
import Link from "next/link"

interface FounderCardProps {
  name: string
  title: string
  bio: string
  image: string
  socialLinks?: {
    linkedin?: string
    twitter?: string
  }
}

export function FounderCard({ name, title, bio, image, socialLinks }: FounderCardProps) {
  return (
    <Card className="overflow-hidden">
      <div className="aspect-square overflow-hidden">
        <img
          src={image || "/placeholder.svg"}
          alt={name}
          className="h-full w-full object-cover transition-all hover:scale-105"
        />
      </div>
      <CardContent className="p-6">
        <h3 className="text-xl font-bold">{name}</h3>
        <p className="text-gray-500">{title}</p>
        <p className="mt-3 text-sm">{bio}</p>

        {socialLinks && (
          <div className="flex mt-4 space-x-2">
            {socialLinks.linkedin && (
              <Button variant="outline" size="icon" asChild>
                <Link href={socialLinks.linkedin} target="_blank" rel="noopener noreferrer">
                  <Linkedin className="h-4 w-4" />
                </Link>
              </Button>
            )}
            {socialLinks.twitter && (
              <Button variant="outline" size="icon" asChild>
                <Link href={socialLinks.twitter} target="_blank" rel="noopener noreferrer">
                  <Twitter className="h-4 w-4" />
                </Link>
              </Button>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  )
}

