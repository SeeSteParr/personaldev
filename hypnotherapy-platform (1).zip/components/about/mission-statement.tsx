import { Card, CardContent } from "@/components/ui/card"
import { Heart } from "lucide-react"

export function MissionStatement() {
  return (
    <Card className="bg-primary/5 border-primary/20">
      <CardContent className="pt-6">
        <div className="flex flex-col items-center text-center space-y-4">
          <div className="p-3 bg-primary/10 rounded-full">
            <Heart className="w-6 h-6 text-primary" />
          </div>
          <h3 className="text-2xl font-bold">Our Mission</h3>
          <p className="text-gray-500 md:text-lg max-w-3xl">
            Mind Mastery is dedicated to transforming lives through the power of hypnotherapy and personal development.
            We believe that everyone deserves access to effective mental health resources and techniques that can unlock
            their full potential. Our mission is to educate, empower, and support individuals on their journey to mental
            wellbeing while fostering a community of ethical practitioners committed to making a positive impact.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full mt-4">
            <div className="p-4 bg-white rounded-lg shadow-sm">
              <h4 className="font-medium">Educate</h4>
              <p className="text-sm text-gray-500 mt-1">
                Providing high-quality training and resources in hypnotherapy and NLP
              </p>
            </div>
            <div className="p-4 bg-white rounded-lg shadow-sm">
              <h4 className="font-medium">Empower</h4>
              <p className="text-sm text-gray-500 mt-1">
                Helping individuals overcome challenges and reach their full potential
              </p>
            </div>
            <div className="p-4 bg-white rounded-lg shadow-sm">
              <h4 className="font-medium">Connect</h4>
              <p className="text-sm text-gray-500 mt-1">Building a supportive community of practitioners and clients</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

