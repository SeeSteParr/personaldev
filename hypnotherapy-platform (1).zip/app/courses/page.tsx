"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Search, BookOpen, Clock, Star, Lock } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"

// Mock user data - in a real app, this would come from your auth context
const mockUser = {
  id: "user123",
  name: "John Doe",
  email: "john@example.com",
  tier: "listener", // 'listener', 'guild', or 'therapist'
}

// Mock course data
const courses = [
  {
    id: "course1",
    title: "Foundations of Hypnotherapy",
    description:
      "Learn the fundamental principles and techniques of hypnotherapy in this comprehensive introductory course.",
    instructor: "Dr. Sarah Johnson",
    instructorTitle: "Clinical Hypnotherapist",
    duration: "8 weeks",
    lessons: 24,
    level: "Beginner",
    rating: 4.8,
    reviews: 156,
    enrolled: 1243,
    image: "/placeholder.svg?height=300&width=500",
    progress: 0,
    featured: true,
    categories: ["fundamentals", "certification"],
    requirements: ["No prior experience needed", "Open mind and willingness to learn"],
    preview: true,
  },
  {
    id: "course2",
    title: "Advanced Induction Techniques",
    description:
      "Master advanced hypnotic induction methods to enhance your practice and achieve deeper trance states with clients.",
    instructor: "Michael Williams",
    instructorTitle: "Master Hypnotherapist",
    duration: "6 weeks",
    lessons: 18,
    level: "Intermediate",
    rating: 4.7,
    reviews: 98,
    enrolled: 876,
    image: "/placeholder.svg?height=300&width=500",
    progress: 0,
    featured: false,
    categories: ["techniques", "advanced"],
    requirements: ["Basic understanding of hypnotherapy", "Completion of Foundations course or equivalent"],
    preview: false,
  },
  {
    id: "course3",
    title: "Therapeutic Applications of NLP",
    description:
      "Explore how to integrate Neuro-Linguistic Programming techniques with hypnotherapy for enhanced client outcomes.",
    instructor: "Dr. Emily Chen",
    instructorTitle: "NLP Master Practitioner",
    duration: "10 weeks",
    lessons: 30,
    level: "Intermediate",
    rating: 4.9,
    reviews: 124,
    enrolled: 952,
    image: "/placeholder.svg?height=300&width=500",
    progress: 0,
    featured: true,
    categories: ["nlp", "techniques"],
    requirements: ["Basic understanding of hypnotherapy", "Interest in language patterns and psychology"],
    preview: true,
  },
  {
    id: "course4",
    title: "Clinical Hypnotherapy Certification",
    description:
      "Complete certification program for practicing clinical hypnotherapy, including supervised client sessions and case studies.",
    instructor: "Prof. James Wilson",
    instructorTitle: "Clinical Director",
    duration: "16 weeks",
    lessons: 48,
    level: "Advanced",
    rating: 4.9,
    reviews: 87,
    enrolled: 412,
    image: "/placeholder.svg?height=300&width=500",
    progress: 0,
    featured: true,
    categories: ["clinical", "certification"],
    requirements: [
      "Completion of foundational hypnotherapy training",
      "Minimum of 10 practice sessions",
      "Background in healthcare or counseling recommended",
    ],
    preview: false,
  },
  {
    id: "course5",
    title: "Hypnotherapy for Anxiety and Stress",
    description:
      "Specialized techniques for addressing anxiety, stress, and related conditions through hypnotherapeutic approaches.",
    instructor: "Lisa Thompson",
    instructorTitle: "Anxiety Specialist",
    duration: "6 weeks",
    lessons: 18,
    level: "Intermediate",
    rating: 4.6,
    reviews: 112,
    enrolled: 789,
    image: "/placeholder.svg?height=300&width=500",
    progress: 0,
    featured: false,
    categories: ["specialization", "anxiety"],
    requirements: ["Basic understanding of hypnotherapy", "Interest in mental health applications"],
    preview: true,
  },
  {
    id: "course6",
    title: "Past Life Regression Techniques",
    description: "Learn how to safely and effectively conduct past life regression sessions with clients.",
    instructor: "Robert Davis",
    instructorTitle: "Regression Specialist",
    duration: "4 weeks",
    lessons: 12,
    level: "Intermediate",
    rating: 4.5,
    reviews: 76,
    enrolled: 523,
    image: "/placeholder.svg?height=300&width=500",
    progress: 0,
    featured: false,
    categories: ["specialization", "regression"],
    requirements: ["Strong foundation in hypnotic inductions", "Ethical practice understanding"],
    preview: false,
  },
]

// Mock enrolled courses
const enrolledCourses = [
  {
    id: "course1",
    progress: 65,
  },
  {
    id: "course3",
    progress: 30,
  },
]

export default function CoursesPage() {
  const router = useRouter()
  const { toast } = useToast()
  const [searchQuery, setSearchQuery] = useState("")
  const [user, setUser] = useState(mockUser)
  const [userCourses, setUserCourses] = useState<typeof courses>([])

  // In a real app, you would fetch the user's tier from your auth context
  useEffect(() => {
    // Simulate loading user data
    // In a real app, this would be fetched from your auth service
  }, [])

  // In a real app, you would fetch the user's enrolled courses
  useEffect(() => {
    if (user.tier === "listener") {
      setUserCourses([])
      return
    }

    // Map enrolled courses to full course data with progress
    const enrolled = courses
      .filter((course) => enrolledCourses.some((ec) => ec.id === course.id))
      .map((course) => {
        const enrolledCourse = enrolledCourses.find((ec) => ec.id === course.id)
        return {
          ...course,
          progress: enrolledCourse ? enrolledCourse.progress : 0,
        }
      })

    setUserCourses(enrolled)
  }, [user.tier])

  // Filter courses based on search query
  const filteredCourses = courses.filter(
    (course) =>
      course.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      course.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      course.instructor.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const handleEnrollClick = (courseId: string) => {
    if (user.tier === "listener") {
      toast({
        title: "Membership Upgrade Required",
        description: "You need to be a Guild Member (Tier 2) or higher to access courses.",
        variant: "destructive",
      })
      router.push("/membership/upgrade")
      return
    }

    router.push(`/courses/${courseId}`)
  }

  const handleContinueClick = (courseId: string) => {
    router.push(`/courses/${courseId}/learn`)
  }

  return (
    <div className="container py-12">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Hypnotherapy Courses</h1>
          <p className="text-muted-foreground mt-1">
            Master the art and science of hypnotherapy with our comprehensive courses
          </p>
        </div>

        {user.tier === "therapist" && <Button onClick={() => router.push("/admin/courses")}>Manage Courses</Button>}
      </div>

      {user.tier === "listener" && (
        <Card className="mb-8 bg-muted/50 border-primary/20">
          <CardHeader>
            <CardTitle>Upgrade Your Membership</CardTitle>
            <CardDescription>
              Guild Members and Certified Therapists have full access to our course library
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p>
              Unlock our comprehensive hypnotherapy courses by upgrading to a Guild Member (Tier 2) membership or
              higher. As a Guild Member, you'll gain access to our full course library, certification opportunities, and
              community support.
            </p>
          </CardContent>
          <CardFooter>
            <Button asChild>
              <Link href="/membership/upgrade">Upgrade Membership</Link>
            </Button>
          </CardFooter>
        </Card>
      )}

      {userCourses.length > 0 && (
        <div className="mb-12">
          <h2 className="text-2xl font-bold mb-6">Continue Learning</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {userCourses.map((course) => (
              <Card key={course.id} className="overflow-hidden">
                <div className="aspect-video relative">
                  <img
                    src={course.image || "/placeholder.svg"}
                    alt={course.title}
                    className="object-cover w-full h-full"
                  />
                  <Badge className="absolute top-2 right-2">{course.level}</Badge>
                </div>
                <CardHeader>
                  <CardTitle>{course.title}</CardTitle>
                  <CardDescription>{course.instructor}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Progress</span>
                        <span>{course.progress}%</span>
                      </div>
                      <Progress value={course.progress} className="h-2" />
                    </div>

                    <div className="flex justify-between text-sm text-muted-foreground">
                      <div className="flex items-center">
                        <BookOpen className="mr-1 h-4 w-4" />
                        {course.lessons} lessons
                      </div>
                      <div className="flex items-center">
                        <Clock className="mr-1 h-4 w-4" />
                        {course.duration}
                      </div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button className="w-full" onClick={() => handleContinueClick(course.id)}>
                    Continue Learning
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </div>
      )}

      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
        <h2 className="text-2xl font-bold">Course Library</h2>
        <div className="w-full md:w-auto">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search courses..."
              className="pl-8 w-full md:w-[300px]"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>
      </div>

      <Tabs defaultValue="all" className="mb-8">
        <TabsList>
          <TabsTrigger value="all">All Courses</TabsTrigger>
          <TabsTrigger value="fundamentals">Fundamentals</TabsTrigger>
          <TabsTrigger value="techniques">Techniques</TabsTrigger>
          <TabsTrigger value="certification">Certification</TabsTrigger>
          <TabsTrigger value="specialization">Specializations</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredCourses.map((course) => (
              <CourseCard key={course.id} course={course} userTier={user.tier} onEnrollClick={handleEnrollClick} />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="fundamentals" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredCourses
              .filter((course) => course.categories.includes("fundamentals"))
              .map((course) => (
                <CourseCard key={course.id} course={course} userTier={user.tier} onEnrollClick={handleEnrollClick} />
              ))}
          </div>
        </TabsContent>

        <TabsContent value="techniques" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredCourses
              .filter((course) => course.categories.includes("techniques"))
              .map((course) => (
                <CourseCard key={course.id} course={course} userTier={user.tier} onEnrollClick={handleEnrollClick} />
              ))}
          </div>
        </TabsContent>

        <TabsContent value="certification" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredCourses
              .filter((course) => course.categories.includes("certification"))
              .map((course) => (
                <CourseCard key={course.id} course={course} userTier={user.tier} onEnrollClick={handleEnrollClick} />
              ))}
          </div>
        </TabsContent>

        <TabsContent value="specialization" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredCourses
              .filter((course) => course.categories.includes("specialization"))
              .map((course) => (
                <CourseCard key={course.id} course={course} userTier={user.tier} onEnrollClick={handleEnrollClick} />
              ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

interface CourseCardProps {
  course: any
  userTier: string
  onEnrollClick: (courseId: string) => void
}

function CourseCard({ course, userTier, onEnrollClick }: CourseCardProps) {
  return (
    <Card className="overflow-hidden h-full flex flex-col">
      <div className="aspect-video relative">
        <img src={course.image || "/placeholder.svg"} alt={course.title} className="object-cover w-full h-full" />
        <Badge className="absolute top-2 right-2">{course.level}</Badge>
        {course.featured && (
          <Badge variant="secondary" className="absolute top-2 left-2">
            Featured
          </Badge>
        )}
      </div>
      <CardHeader>
        <CardTitle>{course.title}</CardTitle>
        <CardDescription>
          <div className="flex items-center">
            <span>{course.instructor}</span>
            <span className="mx-2">•</span>
            <div className="flex items-center">
              <Star className="h-4 w-4 text-yellow-400 fill-yellow-400 mr-1" />
              <span>{course.rating}</span>
              <span className="text-muted-foreground ml-1">({course.reviews})</span>
            </div>
          </div>
        </CardDescription>
      </CardHeader>
      <CardContent className="flex-1">
        <p className="text-muted-foreground line-clamp-3 mb-4">{course.description}</p>
        <div className="flex justify-between text-sm text-muted-foreground">
          <div className="flex items-center">
            <BookOpen className="mr-1 h-4 w-4" />
            {course.lessons} lessons
          </div>
          <div className="flex items-center">
            <Clock className="mr-1 h-4 w-4" />
            {course.duration}
          </div>
        </div>
      </CardContent>
      <CardFooter>
        {userTier === "listener" && !course.preview ? (
          <Button variant="outline" className="w-full" onClick={() => onEnrollClick(course.id)}>
            <Lock className="mr-2 h-4 w-4" />
            Upgrade to Access
          </Button>
        ) : (
          <Button className="w-full" onClick={() => onEnrollClick(course.id)}>
            {course.preview && userTier === "listener" ? "Preview Course" : "Enroll Now"}
          </Button>
        )}
      </CardFooter>
    </Card>
  )
}

