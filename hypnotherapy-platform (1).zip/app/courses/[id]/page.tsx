"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { BookOpen, Clock, Award, Star, Play, FileText, CheckCircle, ChevronLeft, Users, BarChart } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"

// Mock user data - in a real app, this would come from your auth context
const mockUser = {
  id: "user123",
  name: "John Doe",
  email: "john@example.com",
  tier: "guild", // 'listener', 'guild', or 'therapist'
}

// Mock course data
const courses = [
  {
    id: "course1",
    title: "Foundations of Hypnotherapy",
    description:
      "Learn the fundamental principles and techniques of hypnotherapy in this comprehensive introductory course.",
    longDescription:
      "This comprehensive course provides a solid foundation in the principles and practice of hypnotherapy. You'll learn about the history and development of hypnosis, understand the science behind trance states, and master fundamental induction techniques. Through practical exercises and guided practice, you'll develop the skills needed to facilitate basic hypnotic sessions and understand the ethical considerations of hypnotherapeutic practice. This course is ideal for beginners with no prior experience in hypnotherapy or related fields.",
    instructor: "Dr. Sarah Johnson",
    instructorTitle: "Clinical Hypnotherapist",
    instructorBio:
      "Dr. Sarah Johnson is a licensed clinical psychologist and certified hypnotherapist with over 15 years of experience. She specializes in using hypnotherapy for anxiety disorders and has trained hundreds of practitioners worldwide.",
    instructorImage: "/placeholder.svg?height=100&width=100",
    duration: "8 weeks",
    lessons: 24,
    level: "Beginner",
    rating: 4.8,
    reviews: 156,
    enrolled: 1243,
    image: "/placeholder.svg?height=500&width=800",
    featured: true,
    categories: ["fundamentals", "certification"],
    requirements: [
      "No prior experience needed",
      "Open mind and willingness to learn",
      "Basic understanding of psychology helpful but not required",
    ],
    preview: true,
    syllabus: [
      {
        title: "Introduction to Hypnotherapy",
        lessons: [
          { title: "History and Development of Hypnosis", duration: "45 min", type: "video" },
          { title: "Myths and Misconceptions", duration: "30 min", type: "video" },
          { title: "The Science of Trance States", duration: "60 min", type: "video" },
          { title: "Ethical Considerations", duration: "45 min", type: "video" },
        ],
      },
      {
        title: "Basic Induction Techniques",
        lessons: [
          { title: "Progressive Relaxation Method", duration: "60 min", type: "video" },
          { title: "Eye Fixation Technique", duration: "45 min", type: "video" },
          { title: "Guided Visualization", duration: "50 min", type: "video" },
          { title: "Practice Session", duration: "90 min", type: "workshop" },
        ],
      },
      {
        title: "Deepening Techniques",
        lessons: [
          { title: "Counting Methods", duration: "30 min", type: "video" },
          { title: "Fractionation", duration: "45 min", type: "video" },
          { title: "Sensory Awareness", duration: "40 min", type: "video" },
          { title: "Practice Session", duration: "90 min", type: "workshop" },
        ],
      },
      {
        title: "Therapeutic Applications",
        lessons: [
          { title: "Stress Reduction", duration: "60 min", type: "video" },
          { title: "Confidence Building", duration: "60 min", type: "video" },
          { title: "Habit Change Basics", duration: "75 min", type: "video" },
          { title: "Case Studies", duration: "90 min", type: "video" },
        ],
      },
      {
        title: "Practical Skills Development",
        lessons: [
          { title: "Client Intake Process", duration: "45 min", type: "video" },
          { title: "Session Structure", duration: "60 min", type: "video" },
          { title: "Script Development", duration: "75 min", type: "workshop" },
          { title: "Practice Sessions", duration: "120 min", type: "workshop" },
        ],
      },
      {
        title: "Certification Requirements",
        lessons: [
          { title: "Written Examination", duration: "120 min", type: "exam" },
          { title: "Practical Demonstration", duration: "60 min", type: "exam" },
          { title: "Case Study Submission", duration: "N/A", type: "assignment" },
          { title: "Final Review", duration: "60 min", type: "meeting" },
        ],
      },
    ],
    whatYouWillLearn: [
      "The history and scientific basis of hypnotherapy",
      "How to induce hypnotic trance safely and effectively",
      "Techniques for deepening trance states",
      "Basic therapeutic applications of hypnosis",
      "Ethical guidelines for hypnotherapy practice",
      "How to structure a complete hypnotherapy session",
    ],
  },
  // Other courses would be defined here
]

// Mock reviews
const reviews = [
  {
    id: "review1",
    courseId: "course1",
    user: "Michael P.",
    avatar: "/placeholder.svg?height=40&width=40",
    rating: 5,
    date: "2023-10-15",
    content:
      "This course exceeded my expectations. Dr. Johnson is an excellent instructor who explains complex concepts in an accessible way. The practical exercises were particularly valuable.",
  },
  {
    id: "review2",
    courseId: "course1",
    user: "Jennifer L.",
    avatar: "/placeholder.svg?height=40&width=40",
    rating: 4,
    date: "2023-09-22",
    content:
      "A comprehensive introduction to hypnotherapy. I appreciated the balance between theory and practice. Would have liked more case studies, but overall an excellent course.",
  },
  {
    id: "review3",
    courseId: "course1",
    user: "Robert K.",
    avatar: "/placeholder.svg?height=40&width=40",
    rating: 5,
    date: "2023-11-03",
    content:
      "As someone with no prior experience in hypnotherapy, I found this course to be the perfect starting point. The instructor is knowledgeable and engaging, and the course materials are well-organized.",
  },
]

export default function CourseDetailPage() {
  const params = useParams()
  const router = useRouter()
  const { toast } = useToast()
  const [user, setUser] = useState(mockUser)
  const [isEnrolled, setIsEnrolled] = useState(false)

  // Find the course based on the ID from the URL
  const course = courses.find((c) => c.id === params.id)

  // If course not found, show error or redirect
  if (!course) {
    return (
      <div className="container py-12 text-center">
        <h2 className="text-2xl font-bold">Course not found</h2>
        <p className="mt-4">The course you are looking for does not exist.</p>
        <Button className="mt-6" onClick={() => router.push("/courses")}>
          Return to Courses
        </Button>
      </div>
    )
  }

  // Filter reviews for this course
  const courseReviews = reviews.filter((review) => review.courseId === course.id)

  // Check if user is enrolled
  useEffect(() => {
    // In a real app, you would check if the user is enrolled in this course
    // For now, we'll just set it to false
    if (course) {
      setIsEnrolled(false)
    }
  }, [course])

  const handleEnrollClick = () => {
    if (user.tier === "listener" && !course.preview) {
      toast({
        title: "Membership Upgrade Required",
        description: "You need to be a Guild Member (Tier 2) or higher to access this course.",
        variant: "destructive",
      })
      router.push("/membership/upgrade")
      return
    }

    // In a real app, you would enroll the user in the course
    setIsEnrolled(true)

    toast({
      title: "Enrolled Successfully",
      description: `You are now enrolled in ${course.title}.`,
    })

    // Redirect to the course learning page
    router.push(`/courses/${course.id}/learn`)
  }

  return (
    <div className="container py-12">
      <Button variant="ghost" onClick={() => router.push("/courses")} className="mb-6">
        <ChevronLeft className="mr-2 h-4 w-4" />
        Back to Courses
      </Button>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <div className="rounded-lg overflow-hidden mb-6">
            <img src={course.image || "/placeholder.svg"} alt={course.title} className="w-full h-auto object-cover" />
          </div>

          <div className="space-y-6">
            <div>
              <h1 className="text-3xl font-bold">{course.title}</h1>
              <p className="text-muted-foreground mt-2">{course.description}</p>

              <div className="flex items-center mt-4 space-x-4">
                <div className="flex items-center">
                  <Star className="h-5 w-5 text-yellow-400 fill-yellow-400 mr-1" />
                  <span className="font-medium">{course.rating}</span>
                  <span className="text-muted-foreground ml-1">({course.reviews} reviews)</span>
                </div>
                <div className="flex items-center">
                  <Users className="h-5 w-5 mr-1" />
                  <span>{course.enrolled} students</span>
                </div>
                <Badge>{course.level}</Badge>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <Avatar className="h-12 w-12">
                <AvatarImage src={course.instructorImage} alt={course.instructor} />
                <AvatarFallback>{course.instructor.charAt(0)}</AvatarFallback>
              </Avatar>
              <div>
                <p className="font-medium">{course.instructor}</p>
                <p className="text-sm text-muted-foreground">{course.instructorTitle}</p>
              </div>
            </div>

            <Tabs defaultValue="overview">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="curriculum">Curriculum</TabsTrigger>
                <TabsTrigger value="instructor">Instructor</TabsTrigger>
                <TabsTrigger value="reviews">Reviews</TabsTrigger>
              </TabsList>

              <TabsContent value="overview" className="mt-6 space-y-6">
                <div>
                  <h3 className="text-xl font-semibold mb-3">About This Course</h3>
                  <p className="text-muted-foreground">{course.longDescription}</p>
                </div>

                <div>
                  <h3 className="text-xl font-semibold mb-3">What You'll Learn</h3>
                  <ul className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {course.whatYouWillLearn.map((item, index) => (
                      <li key={index} className="flex items-start">
                        <CheckCircle className="h-5 w-5 text-primary mr-2 mt-0.5 shrink-0" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h3 className="text-xl font-semibold mb-3">Requirements</h3>
                  <ul className="space-y-2">
                    {course.requirements.map((req, index) => (
                      <li key={index} className="flex items-start">
                        <CheckCircle className="h-5 w-5 text-primary mr-2 mt-0.5 shrink-0" />
                        <span>{req}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h3 className="text-xl font-semibold mb-3">Course Details</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="flex items-center">
                      <Clock className="h-5 w-5 text-muted-foreground mr-2" />
                      <div>
                        <p className="text-sm text-muted-foreground">Duration</p>
                        <p className="font-medium">{course.duration}</p>
                      </div>
                    </div>
                    <div className="flex items-center">
                      <BookOpen className="h-5 w-5 text-muted-foreground mr-2" />
                      <div>
                        <p className="text-sm text-muted-foreground">Lessons</p>
                        <p className="font-medium">{course.lessons} lessons</p>
                      </div>
                    </div>
                    <div className="flex items-center">
                      <BarChart className="h-5 w-5 text-muted-foreground mr-2" />
                      <div>
                        <p className="text-sm text-muted-foreground">Level</p>
                        <p className="font-medium">{course.level}</p>
                      </div>
                    </div>
                    <div className="flex items-center">
                      <Award className="h-5 w-5 text-muted-foreground mr-2" />
                      <div>
                        <p className="text-sm text-muted-foreground">Certificate</p>
                        <p className="font-medium">Yes, upon completion</p>
                      </div>
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="curriculum" className="mt-6">
                <div className="space-y-4">
                  <h3 className="text-xl font-semibold">Course Curriculum</h3>
                  <p className="text-muted-foreground">
                    {course.lessons} lessons • {course.duration} total length
                  </p>

                  <Accordion type="single" collapsible className="w-full">
                    {course.syllabus.map((module, moduleIndex) => (
                      <AccordionItem key={moduleIndex} value={`module-${moduleIndex}`}>
                        <AccordionTrigger>
                          <div className="flex justify-between items-center w-full pr-4">
                            <span>
                              Module {moduleIndex + 1}: {module.title}
                            </span>
                            <span className="text-sm text-muted-foreground">{module.lessons.length} lessons</span>
                          </div>
                        </AccordionTrigger>
                        <AccordionContent>
                          <div className="space-y-2 pt-2">
                            {module.lessons.map((lesson, lessonIndex) => (
                              <div
                                key={lessonIndex}
                                className="flex items-center justify-between p-2 rounded-md hover:bg-muted"
                              >
                                <div className="flex items-center">
                                  {lesson.type === "video" && <Play className="h-4 w-4 mr-2 text-primary" />}
                                  {lesson.type === "workshop" && <Users className="h-4 w-4 mr-2 text-primary" />}
                                  {lesson.type === "exam" && <FileText className="h-4 w-4 mr-2 text-primary" />}
                                  {lesson.type === "assignment" && <FileText className="h-4 w-4 mr-2 text-primary" />}
                                  {lesson.type === "meeting" && <Users className="h-4 w-4 mr-2 text-primary" />}
                                  <span>{lesson.title}</span>
                                </div>
                                <div className="flex items-center">
                                  <Badge variant="outline">{lesson.type}</Badge>
                                  <span className="ml-2 text-sm text-muted-foreground">{lesson.duration}</span>
                                </div>
                              </div>
                            ))}
                          </div>
                        </AccordionContent>
                      </AccordionItem>
                    ))}
                  </Accordion>
                </div>
              </TabsContent>

              <TabsContent value="instructor" className="mt-6">
                <div className="space-y-4">
                  <div className="flex items-center space-x-4">
                    <Avatar className="h-16 w-16">
                      <AvatarImage src={course.instructorImage} alt={course.instructor} />
                      <AvatarFallback>{course.instructor.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className="text-xl font-semibold">{course.instructor}</h3>
                      <p className="text-muted-foreground">{course.instructorTitle}</p>
                    </div>
                  </div>

                  <p>{course.instructorBio}</p>

                  <div className="grid grid-cols-2 gap-4 pt-4">
                    <div className="bg-muted rounded-md p-4 text-center">
                      <p className="text-2xl font-bold">{course.reviews}</p>
                      <p className="text-sm text-muted-foreground">Reviews</p>
                    </div>
                    <div className="bg-muted rounded-md p-4 text-center">
                      <p className="text-2xl font-bold">{course.enrolled}</p>
                      <p className="text-sm text-muted-foreground">Students</p>
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="reviews" className="mt-6">
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xl font-semibold">Student Reviews</h3>
                    <div className="flex items-center">
                      <Star className="h-5 w-5 text-yellow-400 fill-yellow-400 mr-1" />
                      <span className="font-medium">{course.rating}</span>
                      <span className="text-muted-foreground ml-1">({course.reviews} reviews)</span>
                    </div>
                  </div>

                  <div className="space-y-4">
                    {courseReviews.map((review) => (
                      <Card key={review.id}>
                        <CardContent className="pt-6">
                          <div className="flex items-start justify-between">
                            <div className="flex items-center">
                              <Avatar className="h-10 w-10 mr-3">
                                <AvatarImage src={review.avatar} alt={review.user} />
                                <AvatarFallback>{review.user.charAt(0)}</AvatarFallback>
                              </Avatar>
                              <div>
                                <p className="font-medium">{review.user}</p>
                                <p className="text-sm text-muted-foreground">{review.date}</p>
                              </div>
                            </div>
                            <div className="flex">
                              {[1, 2, 3, 4, 5].map((star) => (
                                <Star
                                  key={star}
                                  className={`h-4 w-4 ${
                                    star <= review.rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
                                  }`}
                                />
                              ))}
                            </div>
                          </div>
                          <p className="mt-4">{review.content}</p>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>

        <div className="lg:col-span-1">
          <Card className="sticky top-24">
            <CardContent className="pt-6">
              <div className="aspect-video rounded-md overflow-hidden bg-muted mb-4">
                <img
                  src={course.image || "/placeholder.svg"}
                  alt={course.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 flex items-center justify-center">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-12 w-12 rounded-full bg-background/80 hover:bg-background/90"
                  >
                    <Play className="h-6 w-6" />
                  </Button>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <p className="text-3xl font-bold">Free</p>
                  <p className="text-sm text-muted-foreground">
                    {user.tier === "listener" && !course.preview
                      ? "Requires Guild Member (Tier 2) or higher"
                      : "Full course access"}
                  </p>
                </div>

                <Button className="w-full" onClick={handleEnrollClick} disabled={isEnrolled}>
                  {isEnrolled ? "Continue Learning" : "Enroll Now"}
                </Button>

                <div className="text-sm text-muted-foreground space-y-2">
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 mr-2" />
                    <span>{course.duration} of content</span>
                  </div>
                  <div className="flex items-center">
                    <BookOpen className="h-4 w-4 mr-2" />
                    <span>{course.lessons} lessons</span>
                  </div>
                  <div className="flex items-center">
                    <Award className="h-4 w-4 mr-2" />
                    <span>Certificate of completion</span>
                  </div>
                  <div className="flex items-center">
                    <Users className="h-4 w-4 mr-2" />
                    <span>{course.enrolled} students enrolled</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

