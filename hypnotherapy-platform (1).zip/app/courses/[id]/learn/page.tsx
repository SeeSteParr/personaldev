"use client"

import { useState, useEffect, useRef } from "react"
import { useParams, useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { ChevronLeft, ChevronRight, Play, Pause, Volume2, VolumeX, CheckCircle } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import { CourseSidebar } from "@/components/course/course-sidebar"
import { CourseQuiz } from "@/components/course/course-quiz"

// Mock user data - in a real app, this would come from your auth context
const mockUser = {
  id: "user123",
  name: "John Doe",
  email: "john@example.com",
  tier: "guild", // 'listener', 'guild', or 'therapist'
}

// Mock course data
const courses = [
  {
    id: "course1",
    title: "Foundations of Hypnotherapy",
    description:
      "Learn the fundamental principles and techniques of hypnotherapy in this comprehensive introductory course.",
    instructor: "Dr. Sarah Johnson",
    instructorTitle: "Clinical Hypnotherapist",
    duration: "8 weeks",
    lessons: 24,
    level: "Beginner",
    image: "/placeholder.svg?height=500&width=800",
    syllabus: [
      {
        id: "module1",
        title: "Introduction to Hypnotherapy",
        lessons: [
          {
            id: "lesson1-1",
            title: "History and Development of Hypnosis",
            duration: "45 min",
            type: "video",
            completed: true,
            content: {
              videoUrl: "https://example.com/video1.mp4",
              transcript: "This is the transcript of the video lesson about the history of hypnosis...",
              description:
                "In this lesson, we explore the fascinating history of hypnosis from ancient practices to modern therapeutic applications.",
            },
          },
          {
            id: "lesson1-2",
            title: "Myths and Misconceptions",
            duration: "30 min",
            type: "video",
            completed: false,
            content: {
              videoUrl: "https://example.com/video2.mp4",
              transcript: "This is the transcript of the video lesson about myths and misconceptions...",
              description: "This lesson addresses common myths and misconceptions about hypnosis and hypnotherapy.",
            },
          },
          {
            id: "lesson1-3",
            title: "The Science of Trance States",
            duration: "60 min",
            type: "video",
            completed: false,
            content: {
              videoUrl: "https://example.com/video3.mp4",
              transcript: "This is the transcript of the video lesson about trance states...",
              description: "Learn about the neurological and psychological aspects of hypnotic trance states.",
            },
          },
          {
            id: "lesson1-4",
            title: "Module 1 Quiz",
            duration: "20 min",
            type: "quiz",
            completed: false,
            content: {
              questions: [
                {
                  id: "q1",
                  question: "Who is often considered the father of modern hypnotherapy?",
                  options: ["Sigmund Freud", "Milton Erickson", "Franz Mesmer", "James Braid"],
                  correctAnswer: "James Braid",
                },
                {
                  id: "q2",
                  question: "Which of the following is NOT a common myth about hypnosis?",
                  options: [
                    "People under hypnosis are unconscious",
                    "Hypnosis can help enhance memory recall",
                    "People can be forced to do things against their will under hypnosis",
                    "Only weak-minded people can be hypnotized",
                  ],
                  correctAnswer: "Hypnosis can help enhance memory recall",
                },
                {
                  id: "q3",
                  question: "What brain wave state is most associated with hypnotic trance?",
                  options: ["Beta waves", "Alpha waves", "Theta waves", "Delta waves"],
                  correctAnswer: "Alpha waves",
                },
              ],
            },
          },
        ],
      },
      {
        id: "module2",
        title: "Basic Induction Techniques",
        lessons: [
          {
            id: "lesson2-1",
            title: "Progressive Relaxation Method",
            duration: "60 min",
            type: "video",
            completed: false,
            content: {
              videoUrl: "https://example.com/video4.mp4",
              transcript: "This is the transcript of the video lesson about progressive relaxation...",
              description:
                "Learn the progressive relaxation induction technique, one of the most widely used methods in hypnotherapy.",
            },
          },
          {
            id: "lesson2-2",
            title: "Eye Fixation Technique",
            duration: "45 min",
            type: "video",
            completed: false,
            content: {
              videoUrl: "https://example.com/video5.mp4",
              transcript: "This is the transcript of the video lesson about eye fixation...",
              description: "Master the classic eye fixation technique for inducing hypnotic trance.",
            },
          },
          {
            id: "lesson2-3",
            title: "Module 2 Assignment",
            duration: "N/A",
            type: "assignment",
            completed: false,
            content: {
              instructions:
                "Record yourself performing a progressive relaxation induction. Your recording should be 5-10 minutes in length and demonstrate proper pacing, voice modulation, and suggestion structure.",
              submissionType: "audio",
              rubric: [
                "Proper pacing and timing",
                "Appropriate voice tone and modulation",
                "Effective use of language patterns",
                "Logical progression of relaxation suggestions",
                "Overall effectiveness of the induction",
              ],
            },
          },
        ],
      },
    ],
    progress: 15,
  },
]

export default function CourseLearnPage() {
  const params = useParams()
  const router = useRouter()
  const { toast } = useToast()
  const [user, setUser] = useState(mockUser)
  const [currentModule, setCurrentModule] = useState(0)
  const [currentLesson, setCurrentLesson] = useState(0)
  const [isPlaying, setIsPlaying] = useState(false)
  const [isMuted, setIsMuted] = useState(false)
  const [progress, setProgress] = useState(0)
  const [notes, setNotes] = useState("")
  const videoRef = useRef<HTMLVideoElement>(null)
  const [hasAccess, setHasAccess] = useState(true)

  // Find the course based on the ID from the URL
  const course = courses.find((c) => c.id === params.id)

  // If course not found, show error or redirect
  if (!course) {
    return (
      <div className="container py-12 text-center">
        <h2 className="text-2xl font-bold">Course not found</h2>
        <p className="mt-4">The course you are looking for does not exist.</p>
        <Button className="mt-6" onClick={() => router.push("/courses")}>
          Return to Courses
        </Button>
      </div>
    )
  }

  // Check if user has access to this course
  useEffect(() => {
    if (user.tier === "listener") {
      setHasAccess(false)
      toast({
        title: "Access Restricted",
        description: "You need to be a Guild Member (Tier 2) or higher to access this course.",
        variant: "destructive",
      })
      router.push("/membership/upgrade")
    } else {
      setHasAccess(true)
    }
  }, [user.tier, router, toast])

  if (!hasAccess) {
    return null // Or a restricted access component
  }

  const currentModuleData = course.syllabus[currentModule]
  const currentLessonData = currentModuleData?.lessons[currentLesson]

  const handlePlayPause = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause()
      } else {
        videoRef.current.play()
      }
      setIsPlaying(!isPlaying)
    }
  }

  const handleMuteToggle = () => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted
      setIsMuted(!isMuted)
    }
  }

  const handleLessonComplete = () => {
    // In a real app, you would update the lesson completion status in your database
    toast({
      title: "Lesson Completed",
      description: `You've completed "${currentLessonData.title}"`,
    })

    // Update progress
    const totalLessons = course.syllabus.reduce((total, module) => total + module.lessons.length, 0)
    const completedLessons = 1 // In a real app, you would count the actual completed lessons
    const newProgress = Math.round((completedLessons / totalLessons) * 100)
    setProgress(newProgress)

    // Move to next lesson if available
    if (currentLesson < currentModuleData.lessons.length - 1) {
      setCurrentLesson(currentLesson + 1)
    } else if (currentModule < course.syllabus.length - 1) {
      setCurrentModule(currentModule + 1)
      setCurrentLesson(0)
    }
  }

  const handlePreviousLesson = () => {
    if (currentLesson > 0) {
      setCurrentLesson(currentLesson - 1)
    } else if (currentModule > 0) {
      setCurrentModule(currentModule - 1)
      setCurrentLesson(course.syllabus[currentModule - 1].lessons.length - 1)
    }
  }

  const handleNextLesson = () => {
    if (currentLesson < currentModuleData.lessons.length - 1) {
      setCurrentLesson(currentLesson + 1)
    } else if (currentModule < course.syllabus.length - 1) {
      setCurrentModule(currentModule + 1)
      setCurrentLesson(0)
    }
  }

  const handleSaveNotes = () => {
    // In a real app, you would save the notes to your database
    toast({
      title: "Notes Saved",
      description: "Your notes have been saved successfully.",
    })
  }

  return (
    <div className="flex h-screen overflow-hidden">
      <CourseSidebar
        course={course}
        currentModule={currentModule}
        currentLesson={currentLesson}
        setCurrentModule={setCurrentModule}
        setCurrentLesson={setCurrentLesson}
      />

      <div className="flex-1 overflow-auto">
        <div className="container py-6">
          <div className="flex items-center justify-between mb-6">
            <Button variant="ghost" onClick={() => router.push(`/courses/${course.id}`)}>
              <ChevronLeft className="mr-2 h-4 w-4" />
              Back to Course
            </Button>
            <div className="flex items-center">
              <span className="text-sm text-muted-foreground mr-2">Course Progress:</span>
              <Progress value={progress} className="w-40 h-2" />
              <span className="text-sm ml-2">{progress}%</span>
            </div>
          </div>

          <div className="space-y-6">
            <div>
              <h1 className="text-2xl font-bold">{currentLessonData.title}</h1>
              <p className="text-muted-foreground">
                Module {currentModule + 1}: {currentModuleData.title} • {currentLessonData.duration}
              </p>
            </div>

            {currentLessonData.type === "video" && (
              <div className="space-y-4">
                <div className="aspect-video bg-black rounded-lg overflow-hidden relative">
                  <video
                    ref={videoRef}
                    src="/placeholder.mp4" // In a real app, use currentLessonData.content.videoUrl
                    className="w-full h-full"
                    poster="/placeholder.svg?height=500&width=800"
                    onPlay={() => setIsPlaying(true)}
                    onPause={() => setIsPlaying(false)}
                  />

                  <div className="absolute bottom-0 left-0 right-0 bg-black/60 text-white p-3 flex items-center justify-between">
                    <Button variant="ghost" size="icon" onClick={handlePlayPause} className="text-white">
                      {isPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
                    </Button>
                    <div className="flex-1 mx-4">
                      <Progress value={30} className="h-1" />
                    </div>
                    <Button variant="ghost" size="icon" onClick={handleMuteToggle} className="text-white">
                      {isMuted ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
                    </Button>
                  </div>
                </div>

                <Tabs defaultValue="description">
                  <TabsList>
                    <TabsTrigger value="description">Description</TabsTrigger>
                    <TabsTrigger value="transcript">Transcript</TabsTrigger>
                    <TabsTrigger value="notes">Notes</TabsTrigger>
                  </TabsList>

                  <TabsContent value="description" className="mt-4">
                    <Card>
                      <CardContent className="pt-6">
                        <p>{currentLessonData.content.description}</p>
                      </CardContent>
                    </Card>
                  </TabsContent>

                  <TabsContent value="transcript" className="mt-4">
                    <Card>
                      <CardContent className="pt-6">
                        <p className="whitespace-pre-line">{currentLessonData.content.transcript}</p>
                      </CardContent>
                    </Card>
                  </TabsContent>

                  <TabsContent value="notes" className="mt-4">
                    <Card>
                      <CardContent className="pt-6">
                        <Textarea
                          placeholder="Take notes on this lesson..."
                          className="min-h-[200px]"
                          value={notes}
                          onChange={(e) => setNotes(e.target.value)}
                        />
                        <Button className="mt-4" onClick={handleSaveNotes}>
                          Save Notes
                        </Button>
                      </CardContent>
                    </Card>
                  </TabsContent>
                </Tabs>
              </div>
            )}

            {currentLessonData.type === "quiz" && (
              <CourseQuiz questions={currentLessonData.content.questions} onComplete={handleLessonComplete} />
            )}

            {currentLessonData.type === "assignment" && (
              <Card>
                <CardHeader>
                  <CardTitle>Assignment: {currentLessonData.title}</CardTitle>
                  <CardDescription>Complete this assignment to progress in the course</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <h3 className="font-medium mb-2">Instructions</h3>
                      <p>{currentLessonData.content.instructions}</p>
                    </div>

                    <div>
                      <h3 className="font-medium mb-2">Grading Rubric</h3>
                      <ul className="list-disc pl-5 space-y-1">
                        {currentLessonData.content.rubric.map((item, index) => (
                          <li key={index}>{item}</li>
                        ))}
                      </ul>
                    </div>

                    <div>
                      <h3 className="font-medium mb-2">Submission</h3>
                      <p className="text-sm text-muted-foreground mb-4">
                        Upload your {currentLessonData.content.submissionType} file below
                      </p>
                      <Button>Upload Submission</Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            <div className="flex justify-between pt-4">
              <Button
                variant="outline"
                onClick={handlePreviousLesson}
                disabled={currentModule === 0 && currentLesson === 0}
              >
                <ChevronLeft className="mr-2 h-4 w-4" />
                Previous Lesson
              </Button>

              <div className="flex gap-2">
                <Button variant="outline" onClick={handleLessonComplete}>
                  <CheckCircle className="mr-2 h-4 w-4" />
                  Mark as Complete
                </Button>

                <Button
                  onClick={handleNextLesson}
                  disabled={
                    currentModule === course.syllabus.length - 1 &&
                    currentLesson === course.syllabus[course.syllabus.length - 1].lessons.length - 1
                  }
                >
                  Next Lesson
                  <ChevronRight className="ml-2 h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

