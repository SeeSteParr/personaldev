"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { useRouter, useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { RadioGroup } from "@/components/ui/radio-group"
import { Checkbox } from "@/components/ui/checkbox"
import { Separator } from "@/components/ui/separator"
import { useToast } from "@/components/ui/use-toast"
import { Github, Twitter, Facebook, Mail, Lock, User, Loader2, AlertCircle } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { SocialLoginButton } from "@/components/auth/social-login-button"
import { ZoomLoginButton } from "@/components/auth/zoom-login-button"
import { SubscriptionTierCard } from "@/components/auth/subscription-tier-card"

export default function RegisterPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const { toast } = useToast()
  const tierParam = searchParams.get("tier")

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
    tier: tierParam || "listener",
  })
  const [acceptTerms, setAcceptTerms] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [activeTab, setActiveTab] = useState<string>("email")

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleTierChange = (tier: string) => {
    setFormData((prev) => ({ ...prev, tier }))
  }

  const validateForm = () => {
    if (!formData.name.trim()) {
      setError("Please enter your name")
      return false
    }
    if (!formData.email.trim()) {
      setError("Please enter your email")
      return false
    }
    if (activeTab === "email") {
      if (!formData.password) {
        setError("Please enter a password")
        return false
      }
      if (formData.password.length < 8) {
        setError("Password must be at least 8 characters")
        return false
      }
      if (formData.password !== formData.confirmPassword) {
        setError("Passwords do not match")
        return false
      }
    }
    if (!acceptTerms) {
      setError("You must accept the terms and conditions")
      return false
    }
    return true
  }

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)

    if (!validateForm()) return

    setIsLoading(true)

    // Here you would implement the actual registration logic with Supabase
    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))
      console.log("Registering with:", formData)

      toast({
        title: "Registration successful",
        description: "Your account has been created successfully!",
      })

      // If user selected a paid tier, redirect to payment page
      if (formData.tier !== "listener") {
        router.push(`/membership/payment?tier=${formData.tier}`)
      } else {
        // Otherwise, redirect to dashboard
        router.push("/dashboard")
      }
    } catch (error) {
      console.error("Registration error:", error)
      setError("Failed to create account. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  const handleSocialRegister = async (provider: string) => {
    setError(null)

    if (!acceptTerms) {
      setError("You must accept the terms and conditions")
      return
    }

    setIsLoading(true)

    // Here you would implement social registration with Supabase
    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))
      console.log(`Registering with ${provider}, tier: ${formData.tier}`)

      toast({
        title: "Registration successful",
        description: `Your account has been created with ${provider}!`,
      })

      // If user selected a paid tier, redirect to payment page
      if (formData.tier !== "listener") {
        router.push(`/membership/payment?tier=${formData.tier}`)
      } else {
        // Otherwise, redirect to dashboard
        router.push("/dashboard")
      }
    } catch (error) {
      console.error(`${provider} registration error:`, error)
      setError(`Failed to register with ${provider}. Please try again.`)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="container py-10">
      <div className="mx-auto max-w-5xl">
        <div className="flex flex-col space-y-2 text-center mb-8">
          <h1 className="text-3xl font-bold tracking-tight">Create an account</h1>
          <p className="text-muted-foreground">Join Mind Mastery and start your journey to personal transformation</p>
        </div>

        {error && (
          <Alert variant="destructive" className="mb-6 max-w-md mx-auto">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="md:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Sign Up</CardTitle>
                <CardDescription>Create your account and choose your membership tier</CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="email" value={activeTab} onValueChange={setActiveTab} className="w-full">
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="email">Email</TabsTrigger>
                    <TabsTrigger value="social">Social & Zoom</TabsTrigger>
                  </TabsList>

                  <TabsContent value="email">
                    <form onSubmit={handleRegister} className="space-y-4 mt-4">
                      <div className="space-y-2">
                        <Label htmlFor="name">Full Name</Label>
                        <div className="relative">
                          <User className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                          <Input
                            id="name"
                            name="name"
                            placeholder="John Doe"
                            className="pl-10"
                            value={formData.name}
                            onChange={handleInputChange}
                            required
                            disabled={isLoading}
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="email">Email</Label>
                        <div className="relative">
                          <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                          <Input
                            id="email"
                            name="email"
                            type="email"
                            placeholder="name@example.com"
                            className="pl-10"
                            value={formData.email}
                            onChange={handleInputChange}
                            required
                            disabled={isLoading}
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="password">Password</Label>
                          <div className="relative">
                            <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                            <Input
                              id="password"
                              name="password"
                              type="password"
                              className="pl-10"
                              value={formData.password}
                              onChange={handleInputChange}
                              required
                              disabled={isLoading}
                            />
                          </div>
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="confirmPassword">Confirm Password</Label>
                          <div className="relative">
                            <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                            <Input
                              id="confirmPassword"
                              name="confirmPassword"
                              type="password"
                              className="pl-10"
                              value={formData.confirmPassword}
                              onChange={handleInputChange}
                              required
                              disabled={isLoading}
                            />
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center space-x-2 pt-2">
                        <Checkbox
                          id="terms"
                          checked={acceptTerms}
                          onCheckedChange={(checked) => setAcceptTerms(checked as boolean)}
                          disabled={isLoading}
                        />
                        <label
                          htmlFor="terms"
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          I accept the{" "}
                          <Link href="/terms" className="text-primary hover:underline">
                            Terms of Service
                          </Link>{" "}
                          and{" "}
                          <Link href="/privacy" className="text-primary hover:underline">
                            Privacy Policy
                          </Link>
                        </label>
                      </div>

                      <Button type="submit" className="w-full" disabled={isLoading}>
                        {isLoading ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Creating account...
                          </>
                        ) : (
                          "Create Account"
                        )}
                      </Button>
                    </form>
                  </TabsContent>

                  <TabsContent value="social">
                    <div className="space-y-4 mt-4">
                      <div className="space-y-2">
                        <Label htmlFor="social-name">Full Name</Label>
                        <div className="relative">
                          <User className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                          <Input
                            id="social-name"
                            name="name"
                            placeholder="John Doe"
                            className="pl-10"
                            value={formData.name}
                            onChange={handleInputChange}
                            required
                            disabled={isLoading}
                          />
                        </div>
                      </div>

                      <SocialLoginButton
                        provider="google"
                        action="Sign up"
                        onClick={() => handleSocialRegister("Google")}
                        disabled={isLoading}
                      />

                      <SocialLoginButton
                        provider="facebook"
                        action="Sign up"
                        icon={<Facebook className="mr-2 h-4 w-4" />}
                        onClick={() => handleSocialRegister("Facebook")}
                        disabled={isLoading}
                      />

                      <SocialLoginButton
                        provider="twitter"
                        action="Sign up"
                        icon={<Twitter className="mr-2 h-4 w-4" />}
                        onClick={() => handleSocialRegister("Twitter")}
                        disabled={isLoading}
                      />

                      <SocialLoginButton
                        provider="github"
                        action="Sign up"
                        icon={<Github className="mr-2 h-4 w-4" />}
                        onClick={() => handleSocialRegister("GitHub")}
                        disabled={isLoading}
                      />

                      <Separator />

                      <ZoomLoginButton
                        action="Sign up"
                        onClick={() => handleSocialRegister("Zoom")}
                        disabled={isLoading}
                      />

                      <div className="flex items-center space-x-2 pt-2">
                        <Checkbox
                          id="social-terms"
                          checked={acceptTerms}
                          onCheckedChange={(checked) => setAcceptTerms(checked as boolean)}
                          disabled={isLoading}
                        />
                        <label
                          htmlFor="social-terms"
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          I accept the{" "}
                          <Link href="/terms" className="text-primary hover:underline">
                            Terms of Service
                          </Link>{" "}
                          and{" "}
                          <Link href="/privacy" className="text-primary hover:underline">
                            Privacy Policy
                          </Link>
                        </label>
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
              <CardFooter className="flex justify-between">
                <div className="text-sm text-muted-foreground">
                  Already have an account?{" "}
                  <Link href="/auth/login" className="text-primary hover:underline">
                    Sign in
                  </Link>
                </div>
              </CardFooter>
            </Card>
          </div>

          <div className="md:col-span-1">
            <div className="space-y-4">
              <h3 className="text-lg font-medium">Choose Your Membership</h3>

              <RadioGroup value={formData.tier} onValueChange={handleTierChange} className="space-y-4">
                <div className="space-y-4">
                  <SubscriptionTierCard
                    id="listener"
                    name="Listener"
                    price="Free"
                    description="Basic access for listeners and clients"
                    features={[
                      "Access to free hypnotherapy sessions",
                      "Browse the store",
                      "Create a basic profile",
                      "Book sessions with therapists",
                    ]}
                    selected={formData.tier === "listener"}
                  />

                  <SubscriptionTierCard
                    id="guild"
                    name="Guild Member"
                    price="£10"
                    period="per month"
                    description="For aspiring hypnotherapists and NLP practitioners"
                    features={[
                      "All Listener features",
                      "Complete hypnotherapy course",
                      "Guild membership",
                      "Upload and share audio content",
                      "Community forum access",
                    ]}
                    selected={formData.tier === "guild"}
                    highlighted
                  />

                  <SubscriptionTierCard
                    id="therapist"
                    name="Certified Therapist"
                    price="£49"
                    period="per month"
                    description="For qualified therapists seeking to grow their practice"
                    features={[
                      "All Guild Member features",
                      "Dedicated therapist profile page",
                      "Professional certification",
                      "Client booking system",
                      "Upload and promote content",
                      "Featured in therapist directory",
                    ]}
                    selected={formData.tier === "therapist"}
                  />
                </div>
              </RadioGroup>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

