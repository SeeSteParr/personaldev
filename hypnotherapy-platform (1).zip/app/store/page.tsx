"use client"

import { useState } from "react"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Search } from "lucide-react"
import { ProductCard } from "@/components/store/product-card"
import { useCart } from "@/components/store/cart-context"
import { CartSheet } from "@/components/store/cart-sheet"

// Mock product data
const products = [
  {
    id: "1",
    name: "Deep Relaxation Audio Session",
    description: "A 30-minute guided hypnotherapy session for deep relaxation and stress relief.",
    price: 12.99,
    category: "audio",
    image: "/placeholder.svg?height=300&width=300",
    featured: true,
  },
  {
    id: "2",
    name: "Confidence Booster Pack",
    description: "A series of 5 hypnotherapy sessions designed to boost your confidence and self-esteem.",
    price: 39.99,
    category: "bundle",
    image: "/placeholder.svg?height=300&width=300",
    featured: true,
  },
  {
    id: "3",
    name: "Sleep Well Hypnosis",
    description: "Fall asleep faster and enjoy deeper, more restful sleep with this guided session.",
    price: 14.99,
    category: "audio",
    image: "/placeholder.svg?height=300&width=300",
    featured: false,
  },
  {
    id: "4",
    name: "Hypnotherapy Fundamentals Book",
    description: "Learn the basics of hypnotherapy with this comprehensive guide for beginners.",
    price: 24.99,
    category: "book",
    image: "/placeholder.svg?height=300&width=300",
    featured: false,
  },
  {
    id: "5",
    name: "Anxiety Relief Program",
    description: "A complete program to help manage and reduce anxiety through hypnotherapy techniques.",
    price: 49.99,
    category: "bundle",
    image: "/placeholder.svg?height=300&width=300",
    featured: true,
  },
  {
    id: "6",
    name: "Weight Management Hypnosis",
    description: "Develop a healthier relationship with food and achieve your weight goals.",
    price: 19.99,
    category: "audio",
    image: "/placeholder.svg?height=300&width=300",
    featured: false,
  },
  {
    id: "7",
    name: "Hypnotic Pendulum",
    description: "Professional-grade hypnotic pendulum for practitioners, made from sterling silver.",
    price: 34.99,
    category: "tool",
    image: "/placeholder.svg?height=300&width=300",
    featured: false,
  },
  {
    id: "8",
    name: "Complete NLP Practitioner Course",
    description: "Digital course materials for becoming an NLP practitioner.",
    price: 199.99,
    category: "course",
    image: "/placeholder.svg?height=300&width=300",
    featured: true,
  },
]

export default function StorePage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [sortOption, setSortOption] = useState("featured")
  const { cartCount } = useCart()

  // Filter products based on search query and category
  const filteredProducts = products.filter((product) => {
    const matchesSearch =
      product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.description.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesCategory = selectedCategory === "all" || product.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  // Sort products based on selected option
  const sortedProducts = [...filteredProducts].sort((a, b) => {
    if (sortOption === "featured") {
      return a.featured === b.featured ? 0 : a.featured ? -1 : 1
    } else if (sortOption === "price-low") {
      return a.price - b.price
    } else if (sortOption === "price-high") {
      return b.price - a.price
    } else if (sortOption === "name") {
      return a.name.localeCompare(b.name)
    }
    return 0
  })

  return (
    <div className="flex flex-col min-h-screen">
      <main className="flex-1">
        <section className="w-full py-12">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
              <div>
                <h2 className="text-3xl font-bold tracking-tight">Store</h2>
                <p className="text-muted-foreground">Browse our collection of hypnotherapy resources and tools</p>
              </div>
              <div className="flex items-center gap-2">
                <CartSheet />
              </div>
            </div>

            <Tabs defaultValue="all-products" className="mt-8">
              <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <TabsList>
                  <TabsTrigger value="all-products">All Products</TabsTrigger>
                  <TabsTrigger value="audio">Audio Sessions</TabsTrigger>
                  <TabsTrigger value="bundles">Bundles</TabsTrigger>
                  <TabsTrigger value="tools">Tools & Books</TabsTrigger>
                </TabsList>
                <div className="flex flex-col gap-4 sm:flex-row">
                  <div className="relative">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      type="search"
                      placeholder="Search products..."
                      className="pl-8 w-full sm:w-[250px]"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                  <Select value={sortOption} onValueChange={setSortOption}>
                    <SelectTrigger className="w-full sm:w-[180px]">
                      <SelectValue placeholder="Sort by" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="featured">Featured</SelectItem>
                      <SelectItem value="price-low">Price: Low to High</SelectItem>
                      <SelectItem value="price-high">Price: High to Low</SelectItem>
                      <SelectItem value="name">Name</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <TabsContent value="all-products" className="mt-6">
                <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                  {sortedProducts.map((product) => (
                    <ProductCard key={product.id} product={product} />
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="audio" className="mt-6">
                <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                  {sortedProducts
                    .filter((product) => product.category === "audio")
                    .map((product) => (
                      <ProductCard key={product.id} product={product} />
                    ))}
                </div>
              </TabsContent>

              <TabsContent value="bundles" className="mt-6">
                <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                  {sortedProducts
                    .filter((product) => product.category === "bundle")
                    .map((product) => (
                      <ProductCard key={product.id} product={product} />
                    ))}
                </div>
              </TabsContent>

              <TabsContent value="tools" className="mt-6">
                <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                  {sortedProducts
                    .filter((product) => ["tool", "book"].includes(product.category))
                    .map((product) => (
                      <ProductCard key={product.id} product={product} />
                    ))}
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </section>
      </main>
    </div>
  )
}

