"use client"

import { useState } from "react"
import Link from "next/link"
import { useParams, useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { ChevronLeft, ShoppingCart, Heart, Share2, Star, Play, Check } from "lucide-react"
import { useCart } from "@/components/store/cart-context"
import { CartSheet } from "@/components/store/cart-sheet"
import { useToast } from "@/components/ui/use-toast"

// Mock product data - in a real app, this would come from your database
const products = [
  {
    id: "1",
    name: "Deep Relaxation Audio Session",
    description: "A 30-minute guided hypnotherapy session for deep relaxation and stress relief.",
    longDescription:
      "This professionally recorded hypnotherapy session is designed to help you achieve a state of deep relaxation. Using proven techniques, our experienced hypnotherapist guides you through a journey that releases tension, calms the mind, and rejuvenates the body. Regular use can help reduce stress, improve sleep quality, and enhance overall wellbeing.",
    price: 12.99,
    category: "audio",
    image: "/placeholder.svg?height=500&width=500",
    featured: true,
    duration: "30 minutes",
    format: "MP3",
    sampleAvailable: true,
    reviews: [
      {
        id: "r1",
        rating: 5,
        author: "Jane D.",
        text: "This session helped me relax like nothing else. Highly recommended!",
      },
      { id: "r2", rating: 4, author: "Mark T.", text: "Great quality recording and effective techniques." },
    ],
    relatedProducts: ["3", "6"],
  },
  {
    id: "2",
    name: "Confidence Booster Pack",
    description: "A series of 5 hypnotherapy sessions designed to boost your confidence and self-esteem.",
    longDescription:
      "Transform your self-confidence with this comprehensive pack of five specialized hypnotherapy sessions. Each session targets a different aspect of confidence building, from public speaking to social situations, personal achievement, self-worth, and positive self-image. The progressive nature of these sessions builds upon each previous one, creating lasting change in how you perceive yourself and your abilities.",
    price: 39.99,
    category: "bundle",
    image: "/placeholder.svg?height=500&width=500",
    featured: true,
    duration: "5 sessions, 25-30 minutes each",
    format: "MP3",
    sampleAvailable: true,
    reviews: [
      {
        id: "r1",
        rating: 5,
        author: "Sarah M.",
        text: "I've noticed a significant improvement in my confidence after just 3 sessions.",
      },
      {
        id: "r2",
        rating: 5,
        author: "David R.",
        text: "Worth every penny. The progression between sessions is well thought out.",
      },
    ],
    relatedProducts: ["5", "8"],
  },
  {
    id: "3",
    name: "Sleep Well Hypnosis",
    description: "Fall asleep faster and enjoy deeper, more restful sleep with this guided session.",
    longDescription:
      "Struggle with insomnia or poor sleep quality? This specialized hypnotherapy session is designed to help you fall asleep faster and enjoy deeper, more restful sleep. Using gentle suggestion techniques and relaxing visualizations, this recording helps quiet the mind, relax the body, and prepare you for a night of quality sleep. Many users report improvements in their sleep patterns after just a few uses.",
    price: 14.99,
    category: "audio",
    image: "/placeholder.svg?height=500&width=500",
    featured: false,
    duration: "45 minutes",
    format: "MP3",
    sampleAvailable: true,
    reviews: [
      {
        id: "r1",
        rating: 5,
        author: "Michael P.",
        text: "I've struggled with insomnia for years. This has been a game-changer.",
      },
      {
        id: "r2",
        rating: 4,
        author: "Lisa J.",
        text: "Very effective. I now fall asleep before the session even ends!",
      },
    ],
    relatedProducts: ["1", "6"],
  },
  {
    id: "4",
    name: "Hypnotherapy Fundamentals Book",
    description: "Learn the basics of hypnotherapy with this comprehensive guide for beginners.",
    longDescription:
      "This comprehensive guide introduces you to the fascinating world of hypnotherapy. Written by experienced practitioners, it covers the history, science, and practical applications of hypnotic techniques. You'll learn about the different states of consciousness, how to induce hypnosis, and ethical considerations for practice. Perfect for beginners interested in the field or those considering hypnotherapy training.",
    price: 24.99,
    category: "book",
    image: "/placeholder.svg?height=500&width=500",
    featured: false,
    format: "PDF & Paperback",
    pages: 240,
    sampleAvailable: true,
    reviews: [
      {
        id: "r1",
        rating: 5,
        author: "Robert K.",
        text: "Excellent introduction to hypnotherapy. Well-written and informative.",
      },
      {
        id: "r2",
        rating: 4,
        author: "Emma S.",
        text: "Great resource for beginners. Clear explanations and practical examples.",
      },
    ],
    relatedProducts: ["7", "8"],
  },
  {
    id: "5",
    name: "Anxiety Relief Program",
    description: "A complete program to help manage and reduce anxiety through hypnotherapy techniques.",
    longDescription:
      "This comprehensive anxiety relief program combines multiple hypnotherapy sessions with practical exercises and techniques to help you manage and reduce anxiety. The program takes a holistic approach, addressing both the symptoms and root causes of anxiety. Sessions include relaxation training, cognitive restructuring, emotional release, and positive visualization. Many users report significant reductions in anxiety levels after completing the program.",
    price: 49.99,
    category: "bundle",
    image: "/placeholder.svg?height=500&width=500",
    featured: true,
    duration: "6 sessions, 30-40 minutes each",
    format: "MP3 & PDF workbook",
    sampleAvailable: true,
    reviews: [
      {
        id: "r1",
        rating: 5,
        author: "Jennifer L.",
        text: "This program has changed my life. My anxiety is now manageable.",
      },
      { id: "r2", rating: 5, author: "Thomas B.", text: "Comprehensive and effective. The workbook adds great value." },
    ],
    relatedProducts: ["1", "2"],
  },
  {
    id: "6",
    name: "Weight Management Hypnosis",
    description: "Develop a healthier relationship with food and achieve your weight goals.",
    longDescription:
      "This specialized hypnotherapy session helps you develop a healthier relationship with food and eating habits. Rather than focusing on restrictive diets, it works on the subconscious patterns that drive eating behaviors. The session helps establish new, healthier associations with food, increases motivation for physical activity, and builds a positive body image. Many users report not only weight changes but also improvements in their overall relationship with food.",
    price: 19.99,
    category: "audio",
    image: "/placeholder.svg?height=500&width=500",
    featured: false,
    duration: "35 minutes",
    format: "MP3",
    sampleAvailable: true,
    reviews: [
      { id: "r1", rating: 4, author: "Patricia N.", text: "Has helped me become more mindful about my eating habits." },
      {
        id: "r2",
        rating: 5,
        author: "Kevin M.",
        text: "I've lost 15 pounds since starting this program. It's changed my relationship with food.",
      },
    ],
    relatedProducts: ["1", "3"],
  },
  {
    id: "7",
    name: "Hypnotic Pendulum",
    description: "Professional-grade hypnotic pendulum for practitioners, made from sterling silver.",
    longDescription:
      "This professional-grade hypnotic pendulum is crafted from sterling silver with meticulous attention to detail. The perfect weight and balance make it ideal for hypnotic inductions. The pendulum features a unique design that naturally draws and holds attention, making it easier to guide clients into trance states. Comes in a velvet-lined box for storage and protection. A must-have tool for professional hypnotherapists.",
    price: 34.99,
    category: "tool",
    image: "/placeholder.svg?height=500&width=500",
    featured: false,
    material: "Sterling Silver",
    length: "4 inches",
    weight: "45 grams",
    reviews: [
      {
        id: "r1",
        rating: 5,
        author: "Dr. James W.",
        text: "Excellent craftsmanship. Perfect weight and balance for professional use.",
      },
      {
        id: "r2",
        rating: 4,
        author: "Maria C.",
        text: "Beautiful pendulum. My clients are drawn to its unique design.",
      },
    ],
    relatedProducts: ["4", "8"],
  },
  {
    id: "8",
    name: "Complete NLP Practitioner Course",
    description: "Digital course materials for becoming an NLP practitioner.",
    longDescription:
      "This comprehensive digital course provides all the materials needed to become a certified NLP (Neuro-Linguistic Programming) practitioner. The course covers all core NLP techniques, including anchoring, reframing, submodalities, and language patterns. Includes video demonstrations, audio guides, and a detailed manual. Perfect for those looking to add NLP skills to their therapeutic practice or for personal development. The course is designed to be self-paced but typically takes 8-12 weeks to complete.",
    price: 199.99,
    category: "course",
    image: "/placeholder.svg?height=500&width=500",
    featured: true,
    duration: "40+ hours of content",
    format: "Video, Audio & PDF",
    certification: "Includes certification exam",
    reviews: [
      {
        id: "r1",
        rating: 5,
        author: "Alexandra T.",
        text: "Incredibly comprehensive. The video demonstrations are particularly helpful.",
      },
      {
        id: "r2",
        rating: 5,
        author: "Richard P.",
        text: "Well-structured course with excellent materials. Worth the investment.",
      },
    ],
    relatedProducts: ["2", "5"],
  },
]

export default function ProductPage() {
  const params = useParams()
  const router = useRouter()
  const { addToCart } = useCart()
  const { toast } = useToast()
  const [quantity, setQuantity] = useState(1)

  // Find the product based on the ID from the URL
  const product = products.find((p) => p.id === params.id)

  // If product not found, show error or redirect
  if (!product) {
    return (
      <div className="container py-12 text-center">
        <h2 className="text-2xl font-bold">Product not found</h2>
        <p className="mt-4">The product you are looking for does not exist.</p>
        <Button className="mt-6" onClick={() => router.push("/store")}>
          Return to Store
        </Button>
      </div>
    )
  }

  // Find related products
  const relatedProducts = product.relatedProducts ? products.filter((p) => product.relatedProducts.includes(p.id)) : []

  const handleAddToCart = () => {
    addToCart({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      quantity,
    })

    toast({
      title: "Added to cart",
      description: `${product.name} has been added to your cart.`,
    })
  }

  return (
    <div className="container py-12">
      <div className="flex items-center mb-6">
        <Button variant="ghost" onClick={() => router.push("/store")}>
          <ChevronLeft className="mr-2 h-4 w-4" />
          Back to Store
        </Button>
        <div className="ml-auto">
          <CartSheet />
        </div>
      </div>

      <div className="grid grid-cols-1 gap-8 md:grid-cols-2">
        {/* Product Image */}
        <div className="rounded-lg overflow-hidden border bg-background">
          <img src={product.image || "/placeholder.svg"} alt={product.name} className="w-full h-auto object-cover" />
        </div>

        {/* Product Details */}
        <div className="space-y-6">
          <div>
            <Badge className="mb-2">{product.category.charAt(0).toUpperCase() + product.category.slice(1)}</Badge>
            <h1 className="text-3xl font-bold">{product.name}</h1>
            <p className="text-2xl font-bold mt-2">£{product.price.toFixed(2)}</p>
          </div>

          <p className="text-muted-foreground">{product.description}</p>

          {product.duration && (
            <div className="flex items-center text-sm">
              <span className="font-medium mr-2">Duration:</span> {product.duration}
            </div>
          )}

          {product.format && (
            <div className="flex items-center text-sm">
              <span className="font-medium mr-2">Format:</span> {product.format}
            </div>
          )}

          <div className="flex items-center space-x-2">
            {[1, 2, 3, 4, 5].map((star) => (
              <Star
                key={star}
                className={`h-5 w-5 ${star <= 4.5 ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`}
              />
            ))}
            <span className="text-sm font-medium">4.5 (18 reviews)</span>
          </div>

          <div className="flex items-center space-x-4">
            <div className="flex items-center border rounded-md">
              <Button
                variant="ghost"
                size="icon"
                className="rounded-r-none"
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
              >
                -
              </Button>
              <div className="w-12 text-center">{quantity}</div>
              <Button variant="ghost" size="icon" className="rounded-l-none" onClick={() => setQuantity(quantity + 1)}>
                +
              </Button>
            </div>
            <Button className="flex-1" onClick={handleAddToCart}>
              <ShoppingCart className="mr-2 h-4 w-4" />
              Add to Cart
            </Button>
          </div>

          {product.sampleAvailable && (
            <Button variant="outline" className="w-full">
              <Play className="mr-2 h-4 w-4" />
              Listen to Sample
            </Button>
          )}

          <div className="flex space-x-4">
            <Button variant="ghost" size="icon">
              <Heart className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon">
              <Share2 className="h-5 w-5" />
            </Button>
          </div>

          <div className="bg-muted p-4 rounded-lg space-y-2">
            <div className="flex items-center">
              <Check className="h-5 w-5 text-green-500 mr-2" />
              <span>Instant digital delivery</span>
            </div>
            <div className="flex items-center">
              <Check className="h-5 w-5 text-green-500 mr-2" />
              <span>Lifetime access</span>
            </div>
            <div className="flex items-center">
              <Check className="h-5 w-5 text-green-500 mr-2" />
              <span>30-day satisfaction guarantee</span>
            </div>
          </div>
        </div>
      </div>

      <Tabs defaultValue="description" className="mt-12">
        <TabsList>
          <TabsTrigger value="description">Description</TabsTrigger>
          <TabsTrigger value="reviews">Reviews</TabsTrigger>
        </TabsList>
        <TabsContent value="description" className="mt-4">
          <Card>
            <CardContent className="pt-6">
              <p>{product.longDescription}</p>

              {product.category === "audio" && (
                <div className="mt-6">
                  <h3 className="font-medium text-lg mb-2">How to Use</h3>
                  <p>
                    Find a quiet, comfortable place where you won't be disturbed. Use headphones for the best
                    experience. Listen to the full session without interruptions. It's normal to fall asleep during the
                    session - your subconscious mind will still absorb the suggestions. For best results, listen
                    regularly for at least 21 days.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="reviews" className="mt-4">
          <Card>
            <CardContent className="pt-6">
              {product.reviews && product.reviews.length > 0 ? (
                <div className="space-y-6">
                  {product.reviews.map((review) => (
                    <div key={review.id} className="pb-6 border-b last:border-0">
                      <div className="flex items-center mb-2">
                        <div className="flex mr-2">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <Star
                              key={star}
                              className={`h-4 w-4 ${
                                star <= review.rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
                              }`}
                            />
                          ))}
                        </div>
                        <span className="font-medium">{review.author}</span>
                      </div>
                      <p className="text-muted-foreground">{review.text}</p>
                    </div>
                  ))}
                </div>
              ) : (
                <p>No reviews yet.</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {relatedProducts.length > 0 && (
        <div className="mt-12">
          <h2 className="text-2xl font-bold mb-6">You May Also Like</h2>
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {relatedProducts.map((product) => (
              <Link key={product.id} href={`/store/${product.id}`}>
                <Card className="h-full overflow-hidden transition-all hover:shadow-md">
                  <div className="aspect-square overflow-hidden">
                    <img
                      src={product.image || "/placeholder.svg"}
                      alt={product.name}
                      className="h-full w-full object-cover transition-all hover:scale-105"
                    />
                  </div>
                  <CardContent className="p-4">
                    <h3 className="font-semibold">{product.name}</h3>
                    <p className="text-sm text-muted-foreground line-clamp-2 mt-2">{product.description}</p>
                    <p className="font-bold mt-2">£{product.price.toFixed(2)}</p>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

