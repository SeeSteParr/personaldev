import Link from "next/link"
import type { Metadata } from "next"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Heart,
  Target,
  Users,
  Building,
  FileText,
  ArrowRight,
  CheckCircle,
  Award,
  BookOpen,
  Headphones,
  Globe,
} from "lucide-react"
import { FounderCard } from "@/components/about/founder-card"
import { TestimonialCard } from "@/components/about/testimonial-card"
import { MissionStatement } from "@/components/about/mission-statement"
import { AboutHero } from "@/components/about/about-hero"
import { AboutCTA } from "@/components/about/about-cta"

export const metadata: Metadata = {
  title: "About Mind Mastery | Our Mission and Vision for Hypnotherapy",
  description:
    "Learn about Mind Mastery's mission to transform lives through hypnotherapy, NLP, and personal development. Meet our founders and discover our non-profit work.",
  keywords:
    "hypnotherapy, NLP, personal development, mind mastery, mental health, therapy, meditation, mindfulness, non-profit",
  openGraph: {
    title: "About Mind Mastery | Our Mission and Vision for Hypnotherapy",
    description:
      "Learn about Mind Mastery's mission to transform lives through hypnotherapy, NLP, and personal development. Meet our founders and discover our non-profit work.",
    url: "https://mindmastery.org/about",
    type: "website",
    images: [
      {
        url: "/og-image.jpg",
        width: 1200,
        height: 630,
        alt: "Mind Mastery - Hypnotherapy & Personal Development",
      },
    ],
  },
}

export default function AboutPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <main className="flex-1">
        <AboutHero />

        <section className="py-12 md:py-24 bg-white">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
              <Badge className="px-3.5 py-1.5">Our Story</Badge>
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                Transforming Lives Through Hypnotherapy
              </h2>
              <p className="max-w-[700px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed mx-auto">
                Founded in 2015, Mind Mastery has been at the forefront of making hypnotherapy and personal development
                accessible to everyone.
              </p>
            </div>

            <MissionStatement />

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16">
              <Card className="bg-primary/5 border-primary/20">
                <CardContent className="pt-6">
                  <div className="flex flex-col items-center text-center space-y-3">
                    <div className="p-3 bg-primary/10 rounded-full">
                      <BookOpen className="w-6 h-6 text-primary" />
                    </div>
                    <h3 className="text-xl font-bold">Education</h3>
                    <p className="text-gray-500">
                      Providing high-quality educational resources and courses in hypnotherapy and NLP techniques.
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-primary/5 border-primary/20">
                <CardContent className="pt-6">
                  <div className="flex flex-col items-center text-center space-y-3">
                    <div className="p-3 bg-primary/10 rounded-full">
                      <Headphones className="w-6 h-6 text-primary" />
                    </div>
                    <h3 className="text-xl font-bold">Support</h3>
                    <p className="text-gray-500">
                      Creating a supportive community for both practitioners and clients to grow and heal.
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-primary/5 border-primary/20">
                <CardContent className="pt-6">
                  <div className="flex flex-col items-center text-center space-y-3">
                    <div className="p-3 bg-primary/10 rounded-full">
                      <Globe className="w-6 h-6 text-primary" />
                    </div>
                    <h3 className="text-xl font-bold">Accessibility</h3>
                    <p className="text-gray-500">
                      Making mental health resources accessible to everyone, regardless of background or location.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        <section className="py-12 md:py-24 bg-slate-50" id="target-audience">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col md:flex-row gap-12">
              <div className="md:w-1/2 space-y-4">
                <div className="inline-flex items-center rounded-full border px-2.5 py-0.5 text-sm font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 border-transparent bg-primary text-primary-foreground hover:bg-primary/80">
                  <Target className="mr-2 h-4 w-4" />
                  Who We Serve
                </div>
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Our Community</h2>
                <p className="text-gray-500 md:text-xl/relaxed">
                  Mind Mastery serves a diverse community of individuals seeking personal growth and mental wellbeing,
                  as well as practitioners looking to develop their skills.
                </p>

                <div className="space-y-4 mt-6">
                  <div className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-primary mr-2 mt-0.5" />
                    <div>
                      <h3 className="font-medium">Individuals Seeking Growth</h3>
                      <p className="text-gray-500">
                        People looking to overcome challenges, break limiting beliefs, or enhance their personal
                        development journey.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-primary mr-2 mt-0.5" />
                    <div>
                      <h3 className="font-medium">Aspiring Practitioners</h3>
                      <p className="text-gray-500">
                        Students and professionals interested in learning hypnotherapy and NLP techniques to help
                        others.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-primary mr-2 mt-0.5" />
                    <div>
                      <h3 className="font-medium">Certified Therapists</h3>
                      <p className="text-gray-500">
                        Qualified hypnotherapists and NLP practitioners looking to grow their practice and connect with
                        clients.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-primary mr-2 mt-0.5" />
                    <div>
                      <h3 className="font-medium">Mental Health Advocates</h3>
                      <p className="text-gray-500">
                        Organizations and individuals passionate about advancing mental health awareness and
                        accessibility.
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="md:w-1/2">
                <div className="grid grid-cols-2 gap-4 h-full">
                  <div className="grid gap-4">
                    <div className="overflow-hidden rounded-lg">
                      <img
                        src="/placeholder.svg?height=300&width=300"
                        alt="Person meditating"
                        className="h-auto w-full object-cover transition-all hover:scale-105 aspect-square"
                      />
                    </div>
                    <div className="overflow-hidden rounded-lg">
                      <img
                        src="/placeholder.svg?height=300&width=300"
                        alt="Therapist with client"
                        className="h-auto w-full object-cover transition-all hover:scale-105 aspect-square"
                      />
                    </div>
                  </div>
                  <div className="grid gap-4">
                    <div className="overflow-hidden rounded-lg">
                      <img
                        src="/placeholder.svg?height=300&width=300"
                        alt="Group therapy session"
                        className="h-auto w-full object-cover transition-all hover:scale-105 aspect-square"
                      />
                    </div>
                    <div className="overflow-hidden rounded-lg">
                      <img
                        src="/placeholder.svg?height=300&width=300"
                        alt="Person learning online"
                        className="h-auto w-full object-cover transition-all hover:scale-105 aspect-square"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="py-12 md:py-24 bg-white" id="founders">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
              <Badge className="px-3.5 py-1.5">Our Team</Badge>
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Meet Our Founders</h2>
              <p className="max-w-[700px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed mx-auto">
                The visionaries behind Mind Mastery who are dedicated to transforming lives through hypnotherapy and
                personal development.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <FounderCard
                name="Dr. Elizabeth Morgan"
                title="Founder & Clinical Director"
                bio="Dr. Morgan is a clinical psychologist with over 20 years of experience in hypnotherapy. She founded Mind Mastery with the vision of making mental health resources accessible to everyone."
                image="/placeholder.svg?height=400&width=400"
                socialLinks={{
                  linkedin: "https://linkedin.com/in/elizabethmorgan",
                  twitter: "https://twitter.com/drelizabethmorgan",
                }}
              />

              <FounderCard
                name="Professor James Wilson"
                title="Co-Founder & Research Director"
                bio="Professor Wilson brings his extensive background in neuroscience and cognitive psychology to develop evidence-based hypnotherapy techniques and training programs."
                image="/placeholder.svg?height=400&width=400"
                socialLinks={{
                  linkedin: "https://linkedin.com/in/jameswilson",
                  twitter: "https://twitter.com/profwilson",
                }}
              />

              <FounderCard
                name="Sarah Chen, MSc"
                title="Co-Founder & Education Director"
                bio="With a background in educational psychology, Sarah leads our course development and ensures our training programs meet the highest standards of quality and effectiveness."
                image="/placeholder.svg?height=400&width=400"
                socialLinks={{
                  linkedin: "https://linkedin.com/in/sarahchen",
                  twitter: "https://twitter.com/sarahchen",
                }}
              />
            </div>

            <div className="mt-16 text-center">
              <Link href="/team" className="inline-flex items-center text-primary hover:underline">
                Meet our full team
                <ArrowRight className="ml-1 h-4 w-4" />
              </Link>
            </div>
          </div>
        </section>

        <section className="py-12 md:py-24 bg-slate-50" id="non-profit">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col md:flex-row gap-12 items-center">
              <div className="md:w-1/2 space-y-4">
                <div className="inline-flex items-center rounded-full border px-2.5 py-0.5 text-sm font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 border-transparent bg-primary text-primary-foreground hover:bg-primary/80">
                  <Building className="mr-2 h-4 w-4" />
                  Our Organization
                </div>
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl">
                  A Non-Profit Dedicated to Mental Wellbeing
                </h2>
                <p className="text-gray-500 md:text-xl/relaxed">
                  Mind Mastery is a registered non-profit organization (NPO #12345678) committed to advancing mental
                  health through hypnotherapy and personal development.
                </p>

                <div className="space-y-4 mt-6">
                  <div className="flex items-start">
                    <Heart className="h-5 w-5 text-primary mr-2 mt-0.5" />
                    <div>
                      <h3 className="font-medium">Our Mission</h3>
                      <p className="text-gray-500">
                        To transform lives by making hypnotherapy and personal development accessible to everyone,
                        regardless of background or circumstances.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start">
                    <Award className="h-5 w-5 text-primary mr-2 mt-0.5" />
                    <div>
                      <h3 className="font-medium">Accreditations</h3>
                      <p className="text-gray-500">
                        Recognized by the International Association of Hypnotherapists and the National Board for
                        Certified Clinical Hypnotherapists.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start">
                    <Users className="h-5 w-5 text-primary mr-2 mt-0.5" />
                    <div>
                      <h3 className="font-medium">Community Impact</h3>
                      <p className="text-gray-500">
                        We've helped over 10,000 individuals and trained more than 500 certified therapists since our
                        founding in 2015.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="pt-4">
                  <Button asChild variant="outline">
                    <Link href="/impact-report">
                      View Our Annual Impact Report
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </div>
              </div>

              <div className="md:w-1/2">
                <div className="relative">
                  <img
                    src="/placeholder.svg?height=500&width=700"
                    alt="Mind Mastery team working together"
                    className="rounded-lg shadow-lg"
                  />
                  <div className="absolute -bottom-6 -right-6 bg-white p-6 rounded-lg shadow-lg max-w-xs">
                    <blockquote className="text-sm italic">
                      "Our non-profit status allows us to focus entirely on our mission: helping people transform their
                      lives through the power of hypnotherapy."
                    </blockquote>
                    <p className="text-right mt-2 font-medium">— Dr. Elizabeth Morgan, Founder</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="py-12 md:py-24 bg-white" id="testimonials">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
              <Badge className="px-3.5 py-1.5">Testimonials</Badge>
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Success Stories</h2>
              <p className="max-w-[700px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed mx-auto">
                Hear from individuals whose lives have been transformed through our programs.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <TestimonialCard
                quote="Mind Mastery's hypnotherapy course completely changed my approach to anxiety. I've gained tools that have transformed not just my practice, but my own life as well."
                author="Michael P."
                title="Certified Therapist"
                image="/placeholder.svg?height=100&width=100"
                rating={5}
              />

              <TestimonialCard
                quote="As someone who was skeptical about hypnotherapy, I was amazed by the results. The techniques I learned helped me overcome a lifelong phobia in just a few sessions."
                author="Jennifer L."
                title="Guild Member"
                image="/placeholder.svg?height=100&width=100"
                rating={5}
              />

              <TestimonialCard
                quote="The community at Mind Mastery is incredible. I started as a listener and was so inspired that I completed the certification program. Now I help others transform their lives too."
                author="Robert K."
                title="Certified Therapist"
                image="/placeholder.svg?height=100&width=100"
                rating={5}
              />
            </div>

            <div className="mt-16 text-center">
              <Link href="/testimonials" className="inline-flex items-center text-primary hover:underline">
                Read more success stories
                <ArrowRight className="ml-1 h-4 w-4" />
              </Link>
            </div>
          </div>
        </section>

        <section className="py-12 md:py-24 bg-slate-50" id="legal">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
              <Badge className="px-3.5 py-1.5">Legal Information</Badge>
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl">Our Policies & Legal Documents</h2>
              <p className="max-w-[700px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed mx-auto">
                Transparency is important to us. Review our policies and legal documents below.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardContent className="pt-6">
                  <div className="flex flex-col items-center text-center space-y-3">
                    <div className="p-3 bg-primary/10 rounded-full">
                      <FileText className="w-6 h-6 text-primary" />
                    </div>
                    <h3 className="text-lg font-medium">Privacy Policy</h3>
                    <p className="text-sm text-gray-500">How we collect, use, and protect your personal information.</p>
                    <Button variant="outline" asChild className="w-full">
                      <Link href="/privacy-policy">View Policy</Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="flex flex-col items-center text-center space-y-3">
                    <div className="p-3 bg-primary/10 rounded-full">
                      <FileText className="w-6 h-6 text-primary" />
                    </div>
                    <h3 className="text-lg font-medium">Terms of Service</h3>
                    <p className="text-sm text-gray-500">
                      The terms and conditions for using our platform and services.
                    </p>
                    <Button variant="outline" asChild className="w-full">
                      <Link href="/terms-of-service">View Terms</Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="flex flex-col items-center text-center space-y-3">
                    <div className="p-3 bg-primary/10 rounded-full">
                      <FileText className="w-6 h-6 text-primary" />
                    </div>
                    <h3 className="text-lg font-medium">Cookie Policy</h3>
                    <p className="text-sm text-gray-500">
                      Information about how we use cookies and similar technologies.
                    </p>
                    <Button variant="outline" asChild className="w-full">
                      <Link href="/cookie-policy">View Policy</Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="flex flex-col items-center text-center space-y-3">
                    <div className="p-3 bg-primary/10 rounded-full">
                      <FileText className="w-6 h-6 text-primary" />
                    </div>
                    <h3 className="text-lg font-medium">Ethical Guidelines</h3>
                    <p className="text-sm text-gray-500">
                      Our commitment to ethical practices in hypnotherapy and personal development.
                    </p>
                    <Button variant="outline" asChild className="w-full">
                      <Link href="/ethical-guidelines">View Guidelines</Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="mt-12 p-6 bg-muted rounded-lg">
              <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                <div>
                  <h3 className="text-lg font-medium">Non-Profit Registration</h3>
                  <p className="text-sm text-gray-500">
                    Mind Mastery is a registered non-profit organization (NPO #12345678) in the United Kingdom.
                  </p>
                </div>
                <Button variant="outline" asChild>
                  <Link href="/registration-certificate">View Registration Certificate</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>

        <AboutCTA />
      </main>
    </div>
  )
}

