"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Separator } from "@/components/ui/separator"
import { ChevronLeft, Plus, Trash, Upload, Save, FileText, Video, AudioLines } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import { CourseSyllabusEditor } from "@/components/course/course-syllabus-editor"

export default function CreateCoursePage() {
  const router = useRouter()
  const { toast } = useToast()

  const [courseData, setCourseData] = useState({
    title: "",
    description: "",
    longDescription: "",
    level: "beginner",
    category: "fundamentals",
    image: "",
    requirements: [""],
    whatYouWillLearn: [""],
    syllabus: [
      {
        title: "Module 1",
        lessons: [
          {
            title: "Introduction",
            type: "video",
            duration: "30 min",
          },
        ],
      },
    ],
  })

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setCourseData({
      ...courseData,
      [name]: value,
    })
  }

  const handleSelectChange = (name: string, value: string) => {
    setCourseData({
      ...courseData,
      [name]: value,
    })
  }

  const handleRequirementChange = (index: number, value: string) => {
    const updatedRequirements = [...courseData.requirements]
    updatedRequirements[index] = value
    setCourseData({
      ...courseData,
      requirements: updatedRequirements,
    })
  }

  const handleAddRequirement = () => {
    setCourseData({
      ...courseData,
      requirements: [...courseData.requirements, ""],
    })
  }

  const handleRemoveRequirement = (index: number) => {
    const updatedRequirements = [...courseData.requirements]
    updatedRequirements.splice(index, 1)
    setCourseData({
      ...courseData,
      requirements: updatedRequirements,
    })
  }

  const handleLearningOutcomeChange = (index: number, value: string) => {
    const updatedOutcomes = [...courseData.whatYouWillLearn]
    updatedOutcomes[index] = value
    setCourseData({
      ...courseData,
      whatYouWillLearn: updatedOutcomes,
    })
  }

  const handleAddLearningOutcome = () => {
    setCourseData({
      ...courseData,
      whatYouWillLearn: [...courseData.whatYouWillLearn, ""],
    })
  }

  const handleRemoveLearningOutcome = (index: number) => {
    const updatedOutcomes = [...courseData.whatYouWillLearn]
    updatedOutcomes.splice(index, 1)
    setCourseData({
      ...courseData,
      whatYouWillLearn: updatedOutcomes,
    })
  }

  const handleSaveCourse = () => {
    // Validate form
    if (!courseData.title || !courseData.description) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      })
      return
    }

    // In a real app, you would save the course to your database
    toast({
      title: "Course Created",
      description: "Your course has been created successfully.",
    })

    // Redirect to the courses admin page
    router.push("/admin/courses")
  }

  const handlePublishCourse = () => {
    // Validate form
    if (!courseData.title || !courseData.description) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      })
      return
    }

    // In a real app, you would save and publish the course to your database
    toast({
      title: "Course Published",
      description: "Your course has been published successfully.",
    })

    // Redirect to the courses admin page
    router.push("/admin/courses")
  }

  return (
    <div className="container py-12">
      <div className="flex items-center justify-between mb-6">
        <Button variant="ghost" onClick={() => router.push("/admin/courses")}>
          <ChevronLeft className="mr-2 h-4 w-4" />
          Back to Courses
        </Button>
        <div className="flex space-x-2">
          <Button variant="outline" onClick={handleSaveCourse}>
            <Save className="mr-2 h-4 w-4" />
            Save as Draft
          </Button>
          <Button onClick={handlePublishCourse}>Publish Course</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Create New Course</CardTitle>
            <CardDescription>Fill in the details below to create a new hypnotherapy course</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="title">Course Title</Label>
              <Input
                id="title"
                name="title"
                placeholder="e.g., Foundations of Hypnotherapy"
                value={courseData.title}
                onChange={handleInputChange}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Short Description</Label>
              <Textarea
                id="description"
                name="description"
                placeholder="A brief description of your course (1-2 sentences)"
                value={courseData.description}
                onChange={handleInputChange}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="level">Course Level</Label>
                <Select value={courseData.level} onValueChange={(value) => handleSelectChange("level", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select level" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="beginner">Beginner</SelectItem>
                    <SelectItem value="intermediate">Intermediate</SelectItem>
                    <SelectItem value="advanced">Advanced</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="category">Primary Category</Label>
                <Select value={courseData.category} onValueChange={(value) => handleSelectChange("category", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="fundamentals">Fundamentals</SelectItem>
                    <SelectItem value="techniques">Techniques</SelectItem>
                    <SelectItem value="nlp">NLP</SelectItem>
                    <SelectItem value="clinical">Clinical Applications</SelectItem>
                    <SelectItem value="certification">Certification</SelectItem>
                    <SelectItem value="specialization">Specialization</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label>Course Image</Label>
              <div className="border-2 border-dashed rounded-md p-6 flex flex-col items-center justify-center">
                <Upload className="h-8 w-8 text-muted-foreground mb-2" />
                <p className="text-sm text-muted-foreground mb-1">Drag and drop an image, or click to browse</p>
                <p className="text-xs text-muted-foreground">Recommended size: 1280x720px (16:9 ratio)</p>
                <Button variant="outline" size="sm" className="mt-4">
                  Upload Image
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <Tabs defaultValue="details" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="details">Course Details</TabsTrigger>
            <TabsTrigger value="curriculum">Curriculum</TabsTrigger>
            <TabsTrigger value="requirements">Requirements</TabsTrigger>
            <TabsTrigger value="media">Media</TabsTrigger>
          </TabsList>

          <TabsContent value="details">
            <Card>
              <CardHeader>
                <CardTitle>Course Details</CardTitle>
                <CardDescription>Provide detailed information about your course</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="longDescription">Detailed Description</Label>
                  <Textarea
                    id="longDescription"
                    name="longDescription"
                    placeholder="A comprehensive description of your course"
                    className="min-h-[200px]"
                    value={courseData.longDescription}
                    onChange={handleInputChange}
                  />
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label>What Students Will Learn</Label>
                    <Button variant="outline" size="sm" onClick={handleAddLearningOutcome}>
                      <Plus className="h-4 w-4 mr-1" />
                      Add Outcome
                    </Button>
                  </div>

                  {courseData.whatYouWillLearn.map((outcome, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <Input
                        placeholder={`Learning outcome ${index + 1}`}
                        value={outcome}
                        onChange={(e) => handleLearningOutcomeChange(index, e.target.value)}
                      />
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleRemoveLearningOutcome(index)}
                        disabled={courseData.whatYouWillLearn.length <= 1}
                      >
                        <Trash className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="curriculum">
            <Card>
              <CardHeader>
                <CardTitle>Course Curriculum</CardTitle>
                <CardDescription>Create your course structure with modules and lessons</CardDescription>
              </CardHeader>
              <CardContent>
                <CourseSyllabusEditor
                  syllabus={courseData.syllabus}
                  onChange={(syllabus) => setCourseData({ ...courseData, syllabus })}
                />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="requirements">
            <Card>
              <CardHeader>
                <CardTitle>Course Requirements</CardTitle>
                <CardDescription>Specify what students need to know before taking this course</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label>Prerequisites</Label>
                    <Button variant="outline" size="sm" onClick={handleAddRequirement}>
                      <Plus className="h-4 w-4 mr-1" />
                      Add Requirement
                    </Button>
                  </div>

                  {courseData.requirements.map((requirement, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <Input
                        placeholder={`Requirement ${index + 1}`}
                        value={requirement}
                        onChange={(e) => handleRequirementChange(index, e.target.value)}
                      />
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleRemoveRequirement(index)}
                        disabled={courseData.requirements.length <= 1}
                      >
                        <Trash className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="media">
            <Card>
              <CardHeader>
                <CardTitle>Course Media</CardTitle>
                <CardDescription>Upload videos, audio files, and other materials for your course</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Video Lessons</h3>
                  <div className="border-2 border-dashed rounded-md p-6 flex flex-col items-center justify-center">
                    <Video className="h-8 w-8 text-muted-foreground mb-2" />
                    <p className="text-sm text-muted-foreground mb-1">Drag and drop video files, or click to browse</p>
                    <p className="text-xs text-muted-foreground">Supported formats: MP4, MOV, AVI (max 2GB)</p>
                    <Button variant="outline" size="sm" className="mt-4">
                      Upload Videos
                    </Button>
                  </div>
                </div>

                <Separator />

                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Audio Files</h3>
                  <div className="border-2 border-dashed rounded-md p-6 flex flex-col items-center justify-center">
                    <AudioLines className="h-8 w-8 text-muted-foreground mb-2" />
                    <p className="text-sm text-muted-foreground mb-1">Drag and drop audio files, or click to browse</p>
                    <p className="text-xs text-muted-foreground">Supported formats: MP3, WAV, AAC (max 500MB)</p>
                    <Button variant="outline" size="sm" className="mt-4">
                      Upload Audio
                    </Button>
                  </div>
                </div>

                <Separator />

                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Downloadable Materials</h3>
                  <div className="border-2 border-dashed rounded-md p-6 flex flex-col items-center justify-center">
                    <FileText className="h-8 w-8 text-muted-foreground mb-2" />
                    <p className="text-sm text-muted-foreground mb-1">Drag and drop documents, or click to browse</p>
                    <p className="text-xs text-muted-foreground">
                      Supported formats: PDF, DOCX, XLSX, PPTX (max 100MB)
                    </p>
                    <Button variant="outline" size="sm" className="mt-4">
                      Upload Documents
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

