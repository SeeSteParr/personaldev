"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Search, Plus, MoreHorizontal, Edit, Trash, Eye, Users, CheckCircle } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"

// Mock user data - in a real app, this would come from your auth context
const mockUser = {
  id: "user123",
  name: "John Doe",
  email: "john@example.com",
  tier: "therapist", // 'listener', 'guild', or 'therapist'
}

// Mock course data
const courses = [
  {
    id: "course1",
    title: "Foundations of Hypnotherapy",
    description:
      "Learn the fundamental principles and techniques of hypnotherapy in this comprehensive introductory course.",
    instructor: "Dr. Sarah Johnson",
    instructorTitle: "Clinical Hypnotherapist",
    duration: "8 weeks",
    lessons: 24,
    level: "Beginner",
    rating: 4.8,
    reviews: 156,
    enrolled: 1243,
    image: "/placeholder.svg?height=300&width=500",
    status: "published",
    lastUpdated: "2023-10-15",
    categories: ["fundamentals", "certification"],
  },
  {
    id: "course2",
    title: "Advanced Induction Techniques",
    description:
      "Master advanced hypnotic induction methods to enhance your practice and achieve deeper trance states with clients.",
    instructor: "Michael Williams",
    instructorTitle: "Master Hypnotherapist",
    duration: "6 weeks",
    lessons: 18,
    level: "Intermediate",
    rating: 4.7,
    reviews: 98,
    enrolled: 876,
    image: "/placeholder.svg?height=300&width=500",
    status: "published",
    lastUpdated: "2023-11-20",
    categories: ["techniques", "advanced"],
  },
  {
    id: "course3",
    title: "Therapeutic Applications of NLP",
    description:
      "Explore how to integrate Neuro-Linguistic Programming techniques with hypnotherapy for enhanced client outcomes.",
    instructor: "Dr. Emily Chen",
    instructorTitle: "NLP Master Practitioner",
    duration: "10 weeks",
    lessons: 30,
    level: "Intermediate",
    rating: 4.9,
    reviews: 124,
    enrolled: 952,
    image: "/placeholder.svg?height=300&width=500",
    status: "published",
    lastUpdated: "2023-09-05",
    categories: ["nlp", "techniques"],
  },
  {
    id: "course4",
    title: "Hypnotherapy for Trauma Resolution",
    description: "Learn specialized approaches for addressing trauma through hypnotherapeutic interventions.",
    instructor: "Dr. Sarah Johnson",
    instructorTitle: "Clinical Hypnotherapist",
    duration: "8 weeks",
    lessons: 24,
    level: "Advanced",
    rating: 0,
    reviews: 0,
    enrolled: 0,
    image: "/placeholder.svg?height=300&width=500",
    status: "draft",
    lastUpdated: "2024-01-10",
    categories: ["specialization", "clinical"],
  },
]

// Mock submissions data
const submissions = [
  {
    id: "sub1",
    courseId: "course1",
    studentName: "Alice Brown",
    studentEmail: "alice@example.com",
    submissionDate: "2024-01-15",
    type: "certification",
    status: "pending",
    score: null,
  },
  {
    id: "sub2",
    courseId: "course1",
    studentName: "Robert Garcia",
    studentEmail: "robert@example.com",
    submissionDate: "2024-01-12",
    type: "assignment",
    status: "reviewed",
    score: 92,
  },
  {
    id: "sub3",
    courseId: "course2",
    studentName: "Jennifer Lee",
    studentEmail: "jennifer@example.com",
    submissionDate: "2024-01-10",
    type: "certification",
    status: "approved",
    score: 95,
  },
]

export default function AdminCoursesPage() {
  const router = useRouter()
  const { toast } = useToast()
  const [searchQuery, setSearchQuery] = useState("")
  const [user, setUser] = useState(mockUser)

  // Check if user has admin access
  if (user.tier !== "therapist") {
    return (
      <div className="container py-12 text-center">
        <h2 className="text-2xl font-bold">Access Denied</h2>
        <p className="mt-4">You need to be a Certified Therapist (Tier 3) to access this area.</p>
        <Button className="mt-6" onClick={() => router.push("/courses")}>
          Return to Courses
        </Button>
      </div>
    )
  }

  // Filter courses based on search query
  const filteredCourses = courses.filter(
    (course) =>
      course.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      course.description.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const handleDeleteCourse = (courseId: string) => {
    // In a real app, you would delete the course from your database
    toast({
      title: "Course Deleted",
      description: "The course has been deleted successfully.",
    })
  }

  const handleApproveSubmission = (submissionId: string) => {
    // In a real app, you would approve the submission in your database
    toast({
      title: "Submission Approved",
      description: "The submission has been approved and certificate generated.",
    })
  }

  return (
    <div className="container py-12">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Course Management</h1>
          <p className="text-muted-foreground mt-1">Create, edit, and manage your hypnotherapy courses</p>
        </div>

        <Button onClick={() => router.push("/admin/courses/create")}>
          <Plus className="mr-2 h-4 w-4" />
          Create New Course
        </Button>
      </div>

      <Tabs defaultValue="courses" className="space-y-6">
        <TabsList>
          <TabsTrigger value="courses">My Courses</TabsTrigger>
          <TabsTrigger value="submissions">Student Submissions</TabsTrigger>
          <TabsTrigger value="certificates">Certificates</TabsTrigger>
        </TabsList>

        <TabsContent value="courses">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-semibold">Your Courses</h2>
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search courses..."
                className="pl-8 w-[300px]"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>

          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Course</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Students</TableHead>
                  <TableHead>Last Updated</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredCourses.map((course) => (
                  <TableRow key={course.id}>
                    <TableCell className="font-medium">
                      <div className="flex items-center space-x-3">
                        <div className="h-10 w-10 rounded-md overflow-hidden bg-muted">
                          <img
                            src={course.image || "/placeholder.svg"}
                            alt={course.title}
                            className="h-full w-full object-cover"
                          />
                        </div>
                        <div>
                          <p className="font-medium">{course.title}</p>
                          <p className="text-sm text-muted-foreground">{course.level}</p>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant={course.status === "published" ? "default" : "secondary"}>
                        {course.status === "published" ? "Published" : "Draft"}
                      </Badge>
                    </TableCell>
                    <TableCell>{course.enrolled}</TableCell>
                    <TableCell>{course.lastUpdated}</TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuLabel>Actions</DropdownMenuLabel>
                          <DropdownMenuItem onClick={() => router.push(`/courses/${course.id}`)}>
                            <Eye className="mr-2 h-4 w-4" />
                            View
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => router.push(`/admin/courses/${course.id}/edit`)}>
                            <Edit className="mr-2 h-4 w-4" />
                            Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => router.push(`/admin/courses/${course.id}/students`)}>
                            <Users className="mr-2 h-4 w-4" />
                            Students
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem
                            onClick={() => handleDeleteCourse(course.id)}
                            className="text-destructive focus:text-destructive"
                          >
                            <Trash className="mr-2 h-4 w-4" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </TabsContent>

        <TabsContent value="submissions">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-semibold">Student Submissions</h2>
          </div>

          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Student</TableHead>
                  <TableHead>Course</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Submitted</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {submissions.map((submission) => {
                  const course = courses.find((c) => c.id === submission.courseId)
                  return (
                    <TableRow key={submission.id}>
                      <TableCell>
                        <div>
                          <p className="font-medium">{submission.studentName}</p>
                          <p className="text-sm text-muted-foreground">{submission.studentEmail}</p>
                        </div>
                      </TableCell>
                      <TableCell>{course?.title || "Unknown Course"}</TableCell>
                      <TableCell>
                        <Badge variant="outline">
                          {submission.type === "certification" ? "Certification" : "Assignment"}
                        </Badge>
                      </TableCell>
                      <TableCell>{submission.submissionDate}</TableCell>
                      <TableCell>
                        <Badge
                          variant={
                            submission.status === "approved"
                              ? "default"
                              : submission.status === "reviewed"
                                ? "secondary"
                                : "outline"
                          }
                        >
                          {submission.status.charAt(0).toUpperCase() + submission.status.slice(1)}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Actions</DropdownMenuLabel>
                            <DropdownMenuItem onClick={() => router.push(`/admin/submissions/${submission.id}`)}>
                              <Eye className="mr-2 h-4 w-4" />
                              View Submission
                            </DropdownMenuItem>
                            {submission.type === "certification" && submission.status === "pending" && (
                              <DropdownMenuItem onClick={() => handleApproveSubmission(submission.id)}>
                                <CheckCircle className="mr-2 h-4 w-4" />
                                Approve & Generate Certificate
                              </DropdownMenuItem>
                            )}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          </div>
        </TabsContent>

        <TabsContent value="certificates">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-semibold">Issued Certificates</h2>
          </div>

          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Student</TableHead>
                  <TableHead>Course</TableHead>
                  <TableHead>Issue Date</TableHead>
                  <TableHead>Certificate ID</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow>
                  <TableCell>
                    <div>
                      <p className="font-medium">Jennifer Lee</p>
                      <p className="text-sm text-muted-foreground">jennifer@example.com</p>
                    </div>
                  </TableCell>
                  <TableCell>Advanced Induction Techniques</TableCell>
                  <TableCell>2024-01-15</TableCell>
                  <TableCell>CERT-2024-0123</TableCell>
                  <TableCell className="text-right">
                    <Button variant="outline" size="sm">
                      <Eye className="mr-2 h-4 w-4" />
                      View
                    </Button>
                  </TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

