"use client"

import { useState } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { RadioGroup } from "@/components/ui/radio-group"
import { useToast } from "@/components/ui/use-toast"
import { Loader2, AlertCircle, CheckCircle, ArrowRight, Crown, Award, Users } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { SubscriptionTierCard } from "@/components/auth/subscription-tier-card"
import { UpgradeBenefitsTable } from "@/components/membership/upgrade-benefits-table"
import { UpgradeFeatureCard } from "@/components/membership/upgrade-feature-card"

export default function UpgradePage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const { toast } = useToast()
  const currentTierParam = searchParams.get("current") || "listener"

  const [selectedTier, setSelectedTier] = useState<string>(
    searchParams.get("tier") || (currentTierParam === "listener" ? "guild" : "therapist"),
  )
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleUpgrade = async () => {
    setError(null)
    setIsLoading(true)

    // Here you would implement the actual upgrade logic with Supabase and payment processing
    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))
      console.log(`Upgrading to ${selectedTier} tier`)

      // Redirect to payment page
      router.push(`/membership/payment?tier=${selectedTier}`)
    } catch (error) {
      console.error("Upgrade error:", error)
      setError("Failed to process upgrade. Please try again.")
      setIsLoading(false)
    }
  }

  return (
    <div className="container py-10">
      <div className="mx-auto max-w-5xl">
        <div className="flex flex-col space-y-2 text-center mb-8">
          <h1 className="text-3xl font-bold tracking-tight">Upgrade Your Membership</h1>
          <p className="text-muted-foreground">Unlock more features and benefits with our premium membership tiers</p>
        </div>

        {error && (
          <Alert variant="destructive" className="mb-6 max-w-md mx-auto">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Your Current Membership</CardTitle>
            <CardDescription>
              You are currently on the {currentTierParam.charAt(0).toUpperCase() + currentTierParam.slice(1)} tier
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center p-4 bg-muted rounded-lg">
              {currentTierParam === "listener" ? (
                <div className="flex items-center">
                  <Users className="h-8 w-8 text-muted-foreground mr-4" />
                  <div>
                    <h3 className="font-medium">Listener (Free)</h3>
                    <p className="text-sm text-muted-foreground">Basic access for listeners and clients</p>
                  </div>
                </div>
              ) : currentTierParam === "guild" ? (
                <div className="flex items-center">
                  <Crown className="h-8 w-8 text-amber-500 mr-4" />
                  <div>
                    <h3 className="font-medium">Guild Member (£10/month)</h3>
                    <p className="text-sm text-muted-foreground">For aspiring hypnotherapists and NLP practitioners</p>
                  </div>
                </div>
              ) : (
                <div className="flex items-center">
                  <Award className="h-8 w-8 text-primary mr-4" />
                  <div>
                    <h3 className="font-medium">Certified Therapist (£49/month)</h3>
                    <p className="text-sm text-muted-foreground">
                      For qualified therapists seeking to grow their practice
                    </p>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          <div className="md:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle>Choose Your Upgrade</CardTitle>
                <CardDescription>Select the membership tier that best suits your needs</CardDescription>
              </CardHeader>
              <CardContent>
                <RadioGroup value={selectedTier} onValueChange={setSelectedTier} className="space-y-4">
                  {currentTierParam === "listener" && (
                    <SubscriptionTierCard
                      id="guild"
                      name="Guild Member"
                      price="£10"
                      period="per month"
                      description="For aspiring hypnotherapists and NLP practitioners"
                      features={[
                        "Complete hypnotherapy course",
                        "Guild membership",
                        "Upload and share audio content",
                        "Community forum access",
                      ]}
                      selected={selectedTier === "guild"}
                      highlighted
                    />
                  )}

                  <SubscriptionTierCard
                    id="therapist"
                    name="Certified Therapist"
                    price="£49"
                    period="per month"
                    description="For qualified therapists seeking to grow their practice"
                    features={[
                      "Dedicated therapist profile page",
                      "Professional certification",
                      "Client booking system",
                      "Upload and promote content",
                      "Featured in therapist directory",
                    ]}
                    selected={selectedTier === "therapist"}
                    highlighted={currentTierParam === "guild"}
                  />
                </RadioGroup>
              </CardContent>
              <CardFooter>
                <Button
                  className="w-full"
                  onClick={handleUpgrade}
                  disabled={isLoading || currentTierParam === selectedTier}
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    <>
                      Upgrade Now
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </>
                  )}
                </Button>
              </CardFooter>
            </Card>
          </div>

          <div className="md:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Membership Benefits Comparison</CardTitle>
                <CardDescription>See what features are included in each membership tier</CardDescription>
              </CardHeader>
              <CardContent>
                <UpgradeBenefitsTable currentTier={currentTierParam} />
              </CardContent>
            </Card>
          </div>
        </div>

        <div className="space-y-6">
          <h2 className="text-2xl font-bold tracking-tight text-center">Why Upgrade Your Membership?</h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <UpgradeFeatureCard
              icon={<Users className="h-8 w-8 text-primary" />}
              title="Community Access"
              description="Connect with like-minded individuals and professionals in the hypnotherapy field."
            />

            <UpgradeFeatureCard
              icon={<Crown className="h-8 w-8 text-primary" />}
              title="Professional Development"
              description="Access comprehensive courses and resources to enhance your skills."
            />

            <UpgradeFeatureCard
              icon={<Award className="h-8 w-8 text-primary" />}
              title="Certification & Recognition"
              description="Gain professional certification and establish your credibility in the field."
            />
          </div>

          <div className="bg-muted p-6 rounded-lg mt-8">
            <div className="flex items-start">
              <CheckCircle className="h-5 w-5 text-green-500 mr-3 mt-0.5" />
              <div>
                <h3 className="font-medium">Satisfaction Guarantee</h3>
                <p className="text-sm text-muted-foreground">
                  If you're not satisfied with your membership, you can cancel anytime within the first 30 days for a
                  full refund.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

