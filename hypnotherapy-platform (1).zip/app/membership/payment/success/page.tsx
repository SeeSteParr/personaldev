"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { CheckCircle, Download, Home, BookOpen } from "lucide-react"

export default function PaymentSuccessPage() {
  // Generate a random order number
  const orderNumber = `ORD-${Math.floor(Math.random() * 10000)
    .toString()
    .padStart(4, "0")}`

  return (
    <div className="container max-w-md py-12">
      <Card className="text-center">
        <CardHeader>
          <div className="flex justify-center mb-4">
            <div className="rounded-full bg-green-100 p-3">
              <CheckCircle className="h-12 w-12 text-green-600" />
            </div>
          </div>
          <CardTitle className="text-2xl">Upgrade Successful!</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>Thank you for upgrading your membership. Your payment has been processed successfully.</p>

          <div className="bg-muted p-4 rounded-md">
            <p className="text-sm text-muted-foreground mb-1">Order Number</p>
            <p className="font-medium">{orderNumber}</p>
          </div>

          <p className="text-sm text-muted-foreground">
            A confirmation email has been sent to your email address with all the details of your subscription.
          </p>

          <div className="bg-primary/5 p-4 rounded-md mt-6">
            <h3 className="font-medium mb-2">What's Next?</h3>
            <ul className="text-sm text-left space-y-2">
              <li className="flex items-start">
                <CheckCircle className="h-4 w-4 text-green-600 mr-2 mt-0.5" />
                <span>Explore your new membership benefits</span>
              </li>
              <li className="flex items-start">
                <CheckCircle className="h-4 w-4 text-green-600 mr-2 mt-0.5" />
                <span>Access exclusive content and courses</span>
              </li>
              <li className="flex items-start">
                <CheckCircle className="h-4 w-4 text-green-600 mr-2 mt-0.5" />
                <span>Connect with our community of practitioners</span>
              </li>
            </ul>
          </div>

          <div className="flex justify-center mt-4">
            <Button variant="outline" className="flex items-center">
              <Download className="mr-2 h-4 w-4" />
              Download Receipt
            </Button>
          </div>
        </CardContent>
        <CardFooter className="flex flex-col space-y-2">
          <Button asChild className="w-full">
            <Link href="/dashboard">
              <Home className="mr-2 h-4 w-4" />
              Go to Dashboard
            </Link>
          </Button>
          <Button variant="outline" asChild className="w-full">
            <Link href="/courses">
              <BookOpen className="mr-2 h-4 w-4" />
              Explore Courses
            </Link>
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

