"use client"
import { useParams, useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Separator } from "@/components/ui/separator"
import {
  ChevronLeft,
  Star,
  MapPin,
  Video,
  FileText,
  CheckCircle,
  Clock,
  Users,
  Facebook,
  Twitter,
  Linkedin,
  Instagram,
} from "lucide-react"
import { TherapistContactButtons } from "@/components/therapist/therapist-contact-buttons"
import { TherapistReviews } from "@/components/therapist/therapist-reviews"
import { TherapistAvailability } from "@/components/therapist/therapist-availability"

// Mock therapist data
const therapists = [
  {
    id: "therapist1",
    name: "Dr. Sarah Johnson",
    title: "Clinical Hypnotherapist",
    avatar: "/placeholder.svg?height=300&width=300",
    coverImage: "/placeholder.svg?height=500&width=1200",
    location: "London, UK",
    specialties: ["Anxiety", "Stress Management", "Phobias", "Depression", "Confidence Building"],
    rating: 4.9,
    reviewCount: 124,
    verified: true,
    featured: true,
    online: true,
    inPerson: true,
    bio: "Certified clinical hypnotherapist with over 15 years of experience helping clients overcome anxiety, stress, and phobias.",
    about: `I am a certified clinical hypnotherapist with over 15 years of experience in helping clients overcome various challenges and improve their quality of life. My approach combines traditional hypnotherapy techniques with elements of cognitive behavioral therapy and mindfulness practices.

Having worked with hundreds of clients, I specialize in treating anxiety disorders, stress management, and phobias. I believe in creating a safe, supportive environment where clients can explore their subconscious mind and make positive changes.

My sessions are tailored to each individual's needs, ensuring that you receive personalized care and attention. Whether you're struggling with a specific issue or simply looking to enhance your overall wellbeing, I'm here to guide you through the process.`,
    qualifications: [
      "PhD in Clinical Psychology, University of London",
      "Certified Clinical Hypnotherapist (CCH)",
      "Member of the British Society of Clinical Hypnosis",
      "Certified NLP Master Practitioner",
      "Mindfulness-Based Cognitive Therapy (MBCT) Certification",
    ],
    experience: "15+ years",
    languages: ["English", "French"],
    sessionTypes: ["Individual", "Couples", "Group"],
    sessionLengths: ["60 minutes", "90 minutes"],
    hourlyRate: 85,
    packages: [
      {
        name: "Single Session",
        description: "One 60-minute hypnotherapy session",
        price: 85,
      },
      {
        name: "Starter Package",
        description: "3 sessions of 60 minutes each",
        price: 230,
      },
      {
        name: "Comprehensive Package",
        description: "6 sessions of 60 minutes each plus email support",
        price: 450,
      },
    ],
    contact: {
      email: "sarah.johnson@example.com",
      phone: "+44 20 1234 5678",
      website: "https://www.drsarahjohnson.com",
      whatsapp: "+44 20 1234 5678",
      zoom: "drsarahjohnson",
      socialMedia: {
        facebook: "https://facebook.com/drsarahjohnson",
        twitter: "https://twitter.com/drsarahjohnson",
        linkedin: "https://linkedin.com/in/drsarahjohnson",
        instagram: "https://instagram.com/drsarahjohnson",
      },
    },
    availability: {
      monday: ["9:00 AM - 5:00 PM"],
      tuesday: ["9:00 AM - 5:00 PM"],
      wednesday: ["9:00 AM - 5:00 PM"],
      thursday: ["9:00 AM - 5:00 PM"],
      friday: ["9:00 AM - 3:00 PM"],
      saturday: [],
      sunday: [],
    },
  },
]

export default function TherapistProfilePage() {
  const params = useParams()
  const router = useRouter()

  // Find the therapist based on the ID from the URL
  const therapist = therapists.find((t) => t.id === params.id)

  // If therapist not found, show error or redirect
  if (!therapist) {
    return (
      <div className="container py-12 text-center">
        <h2 className="text-2xl font-bold">Therapist not found</h2>
        <p className="mt-4">The therapist you are looking for does not exist.</p>
        <Button className="mt-6" onClick={() => router.push("/therapists")}>
          View All Therapists
        </Button>
      </div>
    )
  }

  return (
    <div>
      {/* Cover Image */}
      <div className="w-full h-64 bg-muted relative">
        <img
          src={therapist.coverImage || "/placeholder.svg"}
          alt={`${therapist.name} cover`}
          className="w-full h-full object-cover"
        />
      </div>

      <div className="container py-12">
        <Button variant="ghost" onClick={() => router.push("/therapists")} className="mb-6">
          <ChevronLeft className="mr-2 h-4 w-4" />
          Back to Therapists
        </Button>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Therapist Header */}
            <div className="flex flex-col md:flex-row gap-6 items-start">
              <Avatar className="h-24 w-24 border">
                <AvatarImage src={therapist.avatar} alt={therapist.name} />
                <AvatarFallback>{therapist.name.charAt(0)}</AvatarFallback>
              </Avatar>

              <div className="space-y-2">
                <div className="flex items-center flex-wrap gap-2">
                  <h1 className="text-3xl font-bold">{therapist.name}</h1>
                  {therapist.verified && (
                    <Badge variant="secondary" className="gap-1">
                      <CheckCircle className="h-3.5 w-3.5" /> Verified
                    </Badge>
                  )}
                </div>

                <p className="text-xl text-muted-foreground">{therapist.title}</p>

                <div className="flex items-center gap-4">
                  <div className="flex items-center">
                    <MapPin className="h-4 w-4 mr-1 text-muted-foreground" />
                    <span>{therapist.location}</span>
                  </div>

                  <div className="flex items-center">
                    <Star className="h-4 w-4 text-yellow-400 fill-yellow-400 mr-1" />
                    <span className="font-medium">{therapist.rating}</span>
                    <span className="text-muted-foreground ml-1">({therapist.reviewCount} reviews)</span>
                  </div>
                </div>

                <div className="flex flex-wrap gap-2 pt-1">
                  {therapist.specialties.map((specialty) => (
                    <Badge key={specialty} variant="secondary" className="font-normal">
                      {specialty}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>

            <Tabs defaultValue="about" className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="about">About</TabsTrigger>
                <TabsTrigger value="services">Services & Fees</TabsTrigger>
                <TabsTrigger value="qualifications">Qualifications</TabsTrigger>
                <TabsTrigger value="reviews">Reviews</TabsTrigger>
              </TabsList>

              <TabsContent value="about" className="mt-6 space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>About Me</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <p className="whitespace-pre-line">{therapist.about}</p>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4">
                        <div>
                          <h3 className="font-medium mb-2">Experience</h3>
                          <p>{therapist.experience}</p>
                        </div>

                        <div>
                          <h3 className="font-medium mb-2">Languages</h3>
                          <div className="flex flex-wrap gap-2">
                            {therapist.languages.map((language) => (
                              <Badge key={language} variant="outline">
                                {language}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Session Information</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <h3 className="font-medium mb-2">Session Types</h3>
                        <div className="space-y-2">
                          {therapist.sessionTypes.map((type) => (
                            <div key={type} className="flex items-center">
                              <CheckCircle className="h-4 w-4 text-primary mr-2" />
                              <span>{type}</span>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div>
                        <h3 className="font-medium mb-2">Session Lengths</h3>
                        <div className="space-y-2">
                          {therapist.sessionLengths.map((length) => (
                            <div key={length} className="flex items-center">
                              <Clock className="h-4 w-4 text-primary mr-2" />
                              <span>{length}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                    <Separator className="my-6" />

                    <div>
                      <h3 className="font-medium mb-2">Session Formats</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {therapist.online && (
                          <div className="flex items-start">
                            <div className="bg-primary/10 p-2 rounded-full mr-3">
                              <Video className="h-5 w-5 text-primary" />
                            </div>
                            <div>
                              <p className="font-medium">Online Sessions</p>
                              <p className="text-sm text-muted-foreground">Via Zoom, Skype, or other platforms</p>
                            </div>
                          </div>
                        )}

                        {therapist.inPerson && (
                          <div className="flex items-start">
                            <div className="bg-primary/10 p-2 rounded-full mr-3">
                              <Users className="h-5 w-5 text-primary" />
                            </div>
                            <div>
                              <p className="font-medium">In-Person Sessions</p>
                              <p className="text-sm text-muted-foreground">At my office in {therapist.location}</p>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="services" className="mt-6 space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Services & Packages</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      <div>
                        <h3 className="font-medium mb-4">Standard Rate</h3>
                        <p className="text-2xl font-bold">£{therapist.hourlyRate}/hour</p>
                      </div>

                      <Separator />

                      <div>
                        <h3 className="font-medium mb-4">Packages</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                          {therapist.packages.map((pkg, index) => (
                            <Card key={index} className="border-primary/20">
                              <CardHeader className="pb-2">
                                <CardTitle className="text-lg">{pkg.name}</CardTitle>
                                <CardDescription>{pkg.description}</CardDescription>
                              </CardHeader>
                              <CardContent>
                                <p className="text-2xl font-bold">£{pkg.price}</p>
                              </CardContent>
                              <CardFooter>
                                <Button className="w-full">Book Now</Button>
                              </CardFooter>
                            </Card>
                          ))}
                        </div>
                      </div>

                      <div className="bg-muted p-4 rounded-md">
                        <p className="text-sm">
                          <span className="font-medium">Note:</span> Payment plans are available for packages. Please
                          contact me directly to discuss options.
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Availability</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <TherapistAvailability availability={therapist.availability} />

                    <div className="mt-6">
                      <Button className="w-full">Check Availability & Book</Button>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="qualifications" className="mt-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Qualifications & Certifications</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      <div>
                        <h3 className="font-medium mb-3">Education & Certifications</h3>
                        <ul className="space-y-3">
                          {therapist.qualifications.map((qualification, index) => (
                            <li key={index} className="flex items-start">
                              <CheckCircle className="h-5 w-5 text-primary mr-2 mt-0.5 shrink-0" />
                              <span>{qualification}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      <Separator />

                      <div>
                        <h3 className="font-medium mb-3">Verified Credentials</h3>
                        <div className="flex items-center p-3 bg-primary/10 rounded-md">
                          <CheckCircle className="h-5 w-5 text-primary mr-2" />
                          <div>
                            <p className="font-medium">Guild of International Hypnotherapeutic Knights</p>
                            <p className="text-sm text-muted-foreground">Certified Member</p>
                          </div>
                        </div>
                      </div>

                      <div>
                        <h3 className="font-medium mb-3">Certification Document</h3>
                        <div className="border rounded-md p-4 flex items-center justify-between">
                          <div className="flex items-center">
                            <FileText className="h-8 w-8 text-muted-foreground mr-3" />
                            <div>
                              <p className="font-medium">Hypnotherapy Certification</p>
                              <p className="text-sm text-muted-foreground">PDF Certificate</p>
                            </div>
                          </div>
                          <Button variant="outline" size="sm">
                            View Certificate
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="reviews" className="mt-6">
                <TherapistReviews therapistId={therapist.id} />
              </TabsContent>
            </Tabs>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            <Card className="sticky top-6">
              <CardHeader>
                <CardTitle>Contact Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <TherapistContactButtons contact={therapist.contact} />

                <Separator />

                <div>
                  <h3 className="font-medium mb-3">Social Media</h3>
                  <div className="flex space-x-2">
                    {therapist.contact.socialMedia.facebook && (
                      <Button variant="outline" size="icon" asChild>
                        <Link href={therapist.contact.socialMedia.facebook} target="_blank" rel="noopener noreferrer">
                          <Facebook className="h-4 w-4" />
                        </Link>
                      </Button>
                    )}

                    {therapist.contact.socialMedia.twitter && (
                      <Button variant="outline" size="icon" asChild>
                        <Link href={therapist.contact.socialMedia.twitter} target="_blank" rel="noopener noreferrer">
                          <Twitter className="h-4 w-4" />
                        </Link>
                      </Button>
                    )}

                    {therapist.contact.socialMedia.linkedin && (
                      <Button variant="outline" size="icon" asChild>
                        <Link href={therapist.contact.socialMedia.linkedin} target="_blank" rel="noopener noreferrer">
                          <Linkedin className="h-4 w-4" />
                        </Link>
                      </Button>
                    )}

                    {therapist.contact.socialMedia.instagram && (
                      <Button variant="outline" size="icon" asChild>
                        <Link href={therapist.contact.socialMedia.instagram} target="_blank" rel="noopener noreferrer">
                          <Instagram className="h-4 w-4" />
                        </Link>
                      </Button>
                    )}
                  </div>
                </div>

                <Separator />

                <div>
                  <Button className="w-full">Book a Session</Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}

