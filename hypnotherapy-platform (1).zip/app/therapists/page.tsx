"use client"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Search } from "lucide-react"
import { TherapistCard } from "@/components/therapist/therapist-card"

// Mock therapist data
const therapists = [
  {
    id: "therapist1",
    name: "Dr. Sarah Johnson",
    title: "Clinical Hypnotherapist",
    avatar: "/placeholder.svg?height=300&width=300",
    location: "London, UK",
    specialties: ["Anxiety", "Stress Management", "Phobias"],
    rating: 4.9,
    reviewCount: 124,
    verified: true,
    featured: true,
    online: true,
    inPerson: true,
    bio: "Certified clinical hypnotherapist with over 15 years of experience helping clients overcome anxiety, stress, and phobias.",
    hourlyRate: 85,
  },
  {
    id: "therapist2",
    name: "Michael Williams",
    title: "NLP Master Practitioner",
    avatar: "/placeholder.svg?height=300&width=300",
    location: "Manchester, UK",
    specialties: ["Confidence Building", "Weight Management", "Smoking Cessation"],
    rating: 4.7,
    reviewCount: 98,
    verified: true,
    featured: false,
    online: true,
    inPerson: true,
    bio: "Specializing in confidence building and habit change using a blend of hypnotherapy and NLP techniques.",
    hourlyRate: 75,
  },
  {
    id: "therapist3",
    name: "Emily Chen",
    title: "Cognitive Hypnotherapist",
    avatar: "/placeholder.svg?height=300&width=300",
    location: "Birmingham, UK",
    specialties: ["Depression", "Sleep Issues", "Pain Management"],
    rating: 4.8,
    reviewCount: 87,
    verified: true,
    featured: true,
    online: true,
    inPerson: false,
    bio: "Cognitive hypnotherapist helping clients overcome depression, sleep issues, and chronic pain through evidence-based approaches.",
    hourlyRate: 80,
  },
  {
    id: "therapist4",
    name: "Robert Davis",
    title: "Regression Specialist",
    avatar: "/placeholder.svg?height=300&width=300",
    location: "Edinburgh, UK",
    specialties: ["Past Life Regression", "Trauma Release", "Inner Child Work"],
    rating: 4.6,
    reviewCount: 65,
    verified: true,
    featured: false,
    online: true,
    inPerson: true,
    bio: "Specializing in regression therapy to help clients resolve past traumas and discover their inner resources.",
    hourlyRate: 90,
  },
  {
    id: "therapist5",
    name: "Jennifer Lee",
    title: "Sports Performance Specialist",
    avatar: "/placeholder.svg?height=300&width=300",
    location: "Bristol, UK",
    specialties: ["Sports Performance", "Motivation", "Goal Achievement"],
    rating: 4.9,
    reviewCount: 76,
    verified: true,
    featured: false,
    online: true,
    inPerson: true,
    bio: "Helping athletes and professionals achieve peak performance through specialized hypnotherapy techniques.",
    hourlyRate: 95,
  },
  {
    id: "therapist6",
    name: "David Thompson",
    title: "Medical Hypnotherapist",
    avatar: "/placeholder.svg?height=300&width=300",
    location: "Glasgow, UK",
    specialties: ["Chronic Pain", "IBS", "Autoimmune Support"],
    rating: 4.8,
    reviewCount: 92,
    verified: true,
    featured: true,
    online: true,
    inPerson: true,
    bio: "Medical hypnotherapist working alongside healthcare professionals to support patients with chronic conditions.",
    hourlyRate: 100,
  },
]

// Specialty options for filter
const specialtyOptions = [
  "Anxiety",
  "Depression",
  "Stress Management",
  "Phobias",
  "Confidence Building",
  "Weight Management",
  "Smoking Cessation",
  "Sleep Issues",
  "Pain Management",
  "Past Life Regression",
  "Trauma Release",
  "Sports Performance",
  "Motivation",
  "Chronic Pain",
  "IBS",
]

export default function TherapistsPage() {
  const router = useRouter()
  const [searchQuery, setSearchQuery] = useState("")
  const [locationFilter, setLocationFilter] = useState("")
  const [specialtyFilter, setSpecialtyFilter] = useState("")
  const [sessionTypeFilter, setSessionTypeFilter] = useState("all")

  // Filter therapists based on search query and filters
  const filteredTherapists = therapists.filter((therapist) => {
    // Search query filter
    const matchesSearch =
      therapist.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      therapist.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      therapist.bio.toLowerCase().includes(searchQuery.toLowerCase()) ||
      therapist.specialties.some((s) => s.toLowerCase().includes(searchQuery.toLowerCase()))

    // Location filter
    const matchesLocation = !locationFilter || therapist.location.toLowerCase().includes(locationFilter.toLowerCase())

    // Specialty filter
    const matchesSpecialty =
      !specialtyFilter || therapist.specialties.some((s) => s.toLowerCase() === specialtyFilter.toLowerCase())

    // Session type filter
    const matchesSessionType =
      sessionTypeFilter === "all" ||
      (sessionTypeFilter === "online" && therapist.online) ||
      (sessionTypeFilter === "inPerson" && therapist.inPerson)

    return matchesSearch && matchesLocation && matchesSpecialty && matchesSessionType
  })

  return (
    <div className="container py-12">
      <div className="flex flex-col space-y-4">
        <h1 className="text-3xl font-bold tracking-tight">Find a Therapist</h1>
        <p className="text-muted-foreground">
          Connect with certified hypnotherapists and NLP practitioners for personalized sessions
        </p>
      </div>

      <div className="mt-8 grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="md:col-span-1 space-y-6">
          <div className="bg-card rounded-lg border p-4 space-y-4">
            <h2 className="font-semibold">Filters</h2>

            <div className="space-y-2">
              <label className="text-sm font-medium">Location</label>
              <Input
                placeholder="City or region"
                value={locationFilter}
                onChange={(e) => setLocationFilter(e.target.value)}
                className="w-full"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Specialty</label>
              <Select value={specialtyFilter} onValueChange={setSpecialtyFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Select specialty" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Specialties</SelectItem>
                  {specialtyOptions.map((specialty) => (
                    <SelectItem key={specialty} value={specialty.toLowerCase()}>
                      {specialty}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Session Type</label>
              <Tabs defaultValue="all" value={sessionTypeFilter} onValueChange={setSessionTypeFilter}>
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="all">All</TabsTrigger>
                  <TabsTrigger value="online">Online</TabsTrigger>
                  <TabsTrigger value="inPerson">In-Person</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Price Range</label>
              <div className="flex items-center space-x-2">
                <Input placeholder="Min" type="number" className="w-full" />
                <span>-</span>
                <Input placeholder="Max" type="number" className="w-full" />
              </div>
            </div>

            <Button
              variant="outline"
              className="w-full"
              onClick={() => {
                setLocationFilter("")
                setSpecialtyFilter("")
                setSessionTypeFilter("all")
              }}
            >
              Reset Filters
            </Button>
          </div>

          <div className="bg-card rounded-lg border p-4 space-y-4">
            <h2 className="font-semibold">Become a Listed Therapist</h2>
            <p className="text-sm text-muted-foreground">
              Are you a certified hypnotherapist? Join our platform to connect with clients and grow your practice.
            </p>
            <Button className="w-full" asChild>
              <Link href="/membership/upgrade">Upgrade to Tier 3</Link>
            </Button>
          </div>
        </div>

        <div className="md:col-span-3 space-y-6">
          <div className="flex flex-col md:flex-row justify-between gap-4">
            <div className="relative w-full md:w-auto">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search therapists..."
                className="pl-8 w-full md:w-[300px]"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>

            <div className="flex items-center text-sm text-muted-foreground">
              <span>{filteredTherapists.length} therapists found</span>
            </div>
          </div>

          {filteredTherapists.length === 0 ? (
            <div className="bg-card rounded-lg border p-8 text-center">
              <h3 className="font-semibold text-lg mb-2">No therapists found</h3>
              <p className="text-muted-foreground mb-4">
                Try adjusting your filters or search query to find more therapists.
              </p>
              <Button
                variant="outline"
                onClick={() => {
                  setSearchQuery("")
                  setLocationFilter("")
                  setSpecialtyFilter("")
                  setSessionTypeFilter("all")
                }}
              >
                Clear All Filters
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {filteredTherapists.map((therapist) => (
                <TherapistCard key={therapist.id} therapist={therapist} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

