"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Separator } from "@/components/ui/separator"
import { Switch } from "@/components/ui/switch"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import {
  ChevronLeft,
  Plus,
  Trash,
  Upload,
  Save,
  FileText,
  CheckCircle,
  Facebook,
  Twitter,
  Linkedin,
  Instagram,
  Globe,
  Mail,
  Phone,
  MessageSquare,
  Video,
} from "lucide-react"
import { useToast } from "@/components/ui/use-toast"

// Mock user data - in a real app, this would come from your auth context
const mockUser = {
  id: "user123",
  name: "John Doe",
  email: "john@example.com",
  tier: "therapist", // 'listener', 'guild', or 'therapist'
  avatar: "/placeholder.svg?height=300&width=300",
  hasCertificate: true,
}

export default function TherapistProfilePage() {
  const router = useRouter()
  const { toast } = useToast()

  const [profileData, setProfileData] = useState({
    name: "John Doe",
    title: "Clinical Hypnotherapist",
    location: "London, UK",
    bio: "Certified clinical hypnotherapist with over 10 years of experience helping clients overcome anxiety, stress, and phobias.",
    about:
      "I am a certified clinical hypnotherapist with over 10 years of experience in helping clients overcome various challenges and improve their quality of life. My approach combines traditional hypnotherapy techniques with elements of cognitive behavioral therapy and mindfulness practices.",
    specialties: ["Anxiety", "Stress Management", "Phobias"],
    qualifications: [
      "Certified Clinical Hypnotherapist (CCH)",
      "Member of the British Society of Clinical Hypnosis",
      "Certified NLP Practitioner",
    ],
    experience: "10+ years",
    languages: ["English"],
    sessionTypes: ["Individual", "Couples"],
    sessionLengths: ["60 minutes", "90 minutes"],
    hourlyRate: 75,
    online: true,
    inPerson: true,
    contact: {
      email: "john@example.com",
      phone: "+44 20 1234 5678",
      website: "https://www.johndoetherapy.com",
      whatsapp: "+44 20 1234 5678",
      zoom: "johndoe",
      socialMedia: {
        facebook: "https://facebook.com/johndoe",
        twitter: "https://twitter.com/johndoe",
        linkedin: "https://linkedin.com/in/johndoe",
        instagram: "https://instagram.com/johndoe",
      },
    },
    availability: {
      monday: ["9:00 AM - 5:00 PM"],
      tuesday: ["9:00 AM - 5:00 PM"],
      wednesday: ["9:00 AM - 5:00 PM"],
      thursday: ["9:00 AM - 5:00 PM"],
      friday: ["9:00 AM - 3:00 PM"],
      saturday: [],
      sunday: [],
    },
  })

  // Check if user has therapist access
  if (mockUser.tier !== "therapist") {
    return (
      <div className="container py-12 text-center">
        <h2 className="text-2xl font-bold">Access Denied</h2>
        <p className="mt-4">You need to be a Certified Therapist (Tier 3) to access this area.</p>
        <Button className="mt-6" onClick={() => router.push("/membership/upgrade")}>
          Upgrade Membership
        </Button>
      </div>
    )
  }

  // Check if user has certificate
  if (!mockUser.hasCertificate) {
    return (
      <div className="container py-12 text-center">
        <h2 className="text-2xl font-bold">Certificate Required</h2>
        <p className="mt-4">You need to complete your certification to create a therapist profile.</p>
        <Button className="mt-6" onClick={() => router.push("/courses")}>
          View Certification Courses
        </Button>
      </div>
    )
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setProfileData({
      ...profileData,
      [name]: value,
    })
  }

  const handleContactChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setProfileData({
      ...profileData,
      contact: {
        ...profileData.contact,
        [name]: value,
      },
    })
  }

  const handleSocialMediaChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setProfileData({
      ...profileData,
      contact: {
        ...profileData.contact,
        socialMedia: {
          ...profileData.contact.socialMedia,
          [name]: value,
        },
      },
    })
  }

  const handleSpecialtyChange = (index: number, value: string) => {
    const updatedSpecialties = [...profileData.specialties]
    updatedSpecialties[index] = value
    setProfileData({
      ...profileData,
      specialties: updatedSpecialties,
    })
  }

  const handleAddSpecialty = () => {
    setProfileData({
      ...profileData,
      specialties: [...profileData.specialties, ""],
    })
  }

  const handleRemoveSpecialty = (index: number) => {
    const updatedSpecialties = [...profileData.specialties]
    updatedSpecialties.splice(index, 1)
    setProfileData({
      ...profileData,
      specialties: updatedSpecialties,
    })
  }

  const handleQualificationChange = (index: number, value: string) => {
    const updatedQualifications = [...profileData.qualifications]
    updatedQualifications[index] = value
    setProfileData({
      ...profileData,
      qualifications: updatedQualifications,
    })
  }

  const handleAddQualification = () => {
    setProfileData({
      ...profileData,
      qualifications: [...profileData.qualifications, ""],
    })
  }

  const handleRemoveQualification = (index: number) => {
    const updatedQualifications = [...profileData.qualifications]
    updatedQualifications.splice(index, 1)
    setProfileData({
      ...profileData,
      qualifications: updatedQualifications,
    })
  }

  const handleSaveProfile = () => {
    // In a real app, you would save the profile to your database
    toast({
      title: "Profile Saved",
      description: "Your therapist profile has been updated successfully.",
    })
  }

  return (
    <div className="container py-12">
      <div className="flex items-center justify-between mb-6">
        <Button variant="ghost" onClick={() => router.push("/dashboard")}>
          <ChevronLeft className="mr-2 h-4 w-4" />
          Back to Dashboard
        </Button>
        <Button onClick={handleSaveProfile}>
          <Save className="mr-2 h-4 w-4" />
          Save Profile
        </Button>
      </div>

      <div className="grid grid-cols-1 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Therapist Profile</CardTitle>
            <CardDescription>Manage your public therapist profile information</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex flex-col md:flex-row gap-6 items-start">
              <div className="space-y-2">
                <Avatar className="h-24 w-24 border">
                  <AvatarImage src={mockUser.avatar} alt={profileData.name} />
                  <AvatarFallback>{profileData.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <Button variant="outline" size="sm" className="w-full">
                  <Upload className="mr-2 h-4 w-4" />
                  Change Photo
                </Button>
              </div>

              <div className="flex-1 space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Full Name</Label>
                    <Input id="name" name="name" value={profileData.name} onChange={handleInputChange} />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="title">Professional Title</Label>
                    <Input
                      id="title"
                      name="title"
                      placeholder="e.g., Clinical Hypnotherapist"
                      value={profileData.title}
                      onChange={handleInputChange}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="location">Location</Label>
                  <Input
                    id="location"
                    name="location"
                    placeholder="e.g., London, UK"
                    value={profileData.location}
                    onChange={handleInputChange}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="bio">Short Bio (displayed in search results)</Label>
                  <Textarea
                    id="bio"
                    name="bio"
                    placeholder="A brief description of your practice (1-2 sentences)"
                    value={profileData.bio}
                    onChange={handleInputChange}
                  />
                </div>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <Badge variant="secondary" className="gap-1">
                <CheckCircle className="h-3.5 w-3.5" /> Verified
              </Badge>
              <span className="text-sm text-muted-foreground">Your profile is verified with your certification</span>
            </div>
          </CardContent>
        </Card>

        <Tabs defaultValue="about" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="about">About & Services</TabsTrigger>
            <TabsTrigger value="qualifications">Qualifications</TabsTrigger>
            <TabsTrigger value="contact">Contact Info</TabsTrigger>
            <TabsTrigger value="availability">Availability</TabsTrigger>
          </TabsList>

          <TabsContent value="about">
            <Card>
              <CardHeader>
                <CardTitle>About & Services</CardTitle>
                <CardDescription>Tell potential clients about yourself and your services</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="about">About Me</Label>
                  <Textarea
                    id="about"
                    name="about"
                    placeholder="Describe your background, approach, and philosophy"
                    className="min-h-[200px]"
                    value={profileData.about}
                    onChange={handleInputChange}
                  />
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label>Specialties</Label>
                    <Button variant="outline" size="sm" onClick={handleAddSpecialty}>
                      <Plus className="h-4 w-4 mr-1" />
                      Add Specialty
                    </Button>
                  </div>

                  {profileData.specialties.map((specialty, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <Input
                        placeholder={`Specialty ${index + 1}`}
                        value={specialty}
                        onChange={(e) => handleSpecialtyChange(index, e.target.value)}
                      />
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleRemoveSpecialty(index)}
                        disabled={profileData.specialties.length <= 1}
                      >
                        <Trash className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="experience">Years of Experience</Label>
                    <Input
                      id="experience"
                      name="experience"
                      placeholder="e.g., 5+ years"
                      value={profileData.experience}
                      onChange={handleInputChange}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="hourlyRate">Hourly Rate (£)</Label>
                    <Input
                      id="hourlyRate"
                      name="hourlyRate"
                      type="number"
                      value={profileData.hourlyRate}
                      onChange={(e) =>
                        setProfileData({ ...profileData, hourlyRate: Number.parseInt(e.target.value) || 0 })
                      }
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Languages</Label>
                  <div className="flex flex-wrap gap-2">
                    {profileData.languages.map((language, index) => (
                      <Badge key={index} variant="secondary">
                        {language}
                      </Badge>
                    ))}
                    <Button variant="outline" size="sm">
                      <Plus className="h-4 w-4 mr-1" />
                      Add Language
                    </Button>
                  </div>
                </div>

                <Separator />

                <div className="space-y-4">
                  <h3 className="font-medium">Session Options</h3>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <Label htmlFor="online">Online Sessions</Label>
                        <Switch
                          id="online"
                          checked={profileData.online}
                          onCheckedChange={(checked) => setProfileData({ ...profileData, online: checked })}
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <Label htmlFor="inPerson">In-Person Sessions</Label>
                        <Switch
                          id="inPerson"
                          checked={profileData.inPerson}
                          onCheckedChange={(checked) => setProfileData({ ...profileData, inPerson: checked })}
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label>Session Types</Label>
                      <div className="flex flex-wrap gap-2">
                        {profileData.sessionTypes.map((type, index) => (
                          <Badge key={index} variant="secondary">
                            {type}
                          </Badge>
                        ))}
                        <Button variant="outline" size="sm">
                          <Plus className="h-4 w-4 mr-1" />
                          Add Type
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="qualifications">
            <Card>
              <CardHeader>
                <CardTitle>Qualifications & Certifications</CardTitle>
                <CardDescription>Showcase your professional credentials and certifications</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label>Qualifications & Certifications</Label>
                    <Button variant="outline" size="sm" onClick={handleAddQualification}>
                      <Plus className="h-4 w-4 mr-1" />
                      Add Qualification
                    </Button>
                  </div>

                  {profileData.qualifications.map((qualification, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <Input
                        placeholder={`Qualification ${index + 1}`}
                        value={qualification}
                        onChange={(e) => handleQualificationChange(index, e.target.value)}
                      />
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleRemoveQualification(index)}
                        disabled={profileData.qualifications.length <= 1}
                      >
                        <Trash className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>

                <Separator />

                <div>
                  <h3 className="font-medium mb-3">Certification Document</h3>
                  <div className="border rounded-md p-4 flex items-center justify-between">
                    <div className="flex items-center">
                      <FileText className="h-8 w-8 text-muted-foreground mr-3" />
                      <div>
                        <p className="font-medium">Hypnotherapy Certification</p>
                        <p className="text-sm text-muted-foreground">PDF Certificate</p>
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      <Button variant="outline" size="sm">
                        View
                      </Button>
                      <Button variant="outline" size="sm">
                        <Upload className="mr-2 h-4 w-4" />
                        Update
                      </Button>
                    </div>
                  </div>
                </div>

                <div className="bg-muted p-4 rounded-md">
                  <div className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-primary mr-2" />
                    <div>
                      <p className="font-medium">Verification Status: Verified</p>
                      <p className="text-sm text-muted-foreground">Your certification has been verified by our team</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="contact">
            <Card>
              <CardHeader>
                <CardTitle>Contact Information</CardTitle>
                <CardDescription>Manage how potential clients can reach you</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="email">Email Address</Label>
                    <div className="flex items-center space-x-2">
                      <Mail className="h-4 w-4 text-muted-foreground" />
                      <Input id="email" name="email" value={profileData.contact.email} onChange={handleContactChange} />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone Number</Label>
                    <div className="flex items-center space-x-2">
                      <Phone className="h-4 w-4 text-muted-foreground" />
                      <Input id="phone" name="phone" value={profileData.contact.phone} onChange={handleContactChange} />
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="website">Website (optional)</Label>
                    <div className="flex items-center space-x-2">
                      <Globe className="h-4 w-4 text-muted-foreground" />
                      <Input
                        id="website"
                        name="website"
                        value={profileData.contact.website}
                        onChange={handleContactChange}
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="whatsapp">WhatsApp (optional)</Label>
                    <div className="flex items-center space-x-2">
                      <MessageSquare className="h-4 w-4 text-muted-foreground" />
                      <Input
                        id="whatsapp"
                        name="whatsapp"
                        value={profileData.contact.whatsapp}
                        onChange={handleContactChange}
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="zoom">Zoom ID (optional)</Label>
                  <div className="flex items-center space-x-2">
                    <Video className="h-4 w-4 text-muted-foreground" />
                    <Input id="zoom" name="zoom" value={profileData.contact.zoom} onChange={handleContactChange} />
                  </div>
                </div>

                <Separator />

                <div className="space-y-4">
                  <h3 className="font-medium">Social Media Links (optional)</h3>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="facebook">Facebook</Label>
                      <div className="flex items-center space-x-2">
                        <Facebook className="h-4 w-4 text-muted-foreground" />
                        <Input
                          id="facebook"
                          name="facebook"
                          value={profileData.contact.socialMedia.facebook}
                          onChange={handleSocialMediaChange}
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="twitter">Twitter</Label>
                      <div className="flex items-center space-x-2">
                        <Twitter className="h-4 w-4 text-muted-foreground" />
                        <Input
                          id="twitter"
                          name="twitter"
                          value={profileData.contact.socialMedia.twitter}
                          onChange={handleSocialMediaChange}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="linkedin">LinkedIn</Label>
                      <div className="flex items-center space-x-2">
                        <Linkedin className="h-4 w-4 text-muted-foreground" />
                        <Input
                          id="linkedin"
                          name="linkedin"
                          value={profileData.contact.socialMedia.linkedin}
                          onChange={handleSocialMediaChange}
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="instagram">Instagram</Label>
                      <div className="flex items-center space-x-2">
                        <Instagram className="h-4 w-4 text-muted-foreground" />
                        <Input
                          id="instagram"
                          name="instagram"
                          value={profileData.contact.socialMedia.instagram}
                          onChange={handleSocialMediaChange}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="availability">
            <Card>
              <CardHeader>
                <CardTitle>Availability</CardTitle>
                <CardDescription>Set your working hours and availability for sessions</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {Object.entries(profileData.availability).map(([day, slots]) => (
                    <div key={day} className="p-3 border rounded-md">
                      <div className="flex items-center justify-between mb-2">
                        <p className="font-medium capitalize">{day}</p>
                        <Button variant="outline" size="sm">
                          <Plus className="h-4 w-4 mr-1" />
                          Add Time
                        </Button>
                      </div>
                      <div>
                        {slots.length > 0 ? (
                          slots.map((slot, index) => (
                            <div key={index} className="flex items-center justify-between mb-2">
                              <Badge variant="outline">{slot}</Badge>
                              <Button variant="ghost" size="icon">
                                <Trash className="h-4 w-4" />
                              </Button>
                            </div>
                          ))
                        ) : (
                          <p className="text-sm text-muted-foreground">Not available</p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>

                <div className="bg-muted p-4 rounded-md">
                  <p className="text-sm">
                    <span className="font-medium">Note:</span> Your availability will be displayed on your public
                    profile to help clients book sessions with you.
                  </p>
                </div>
              </CardContent>
              <CardFooter>
                <Button className="w-full" onClick={handleSaveProfile}>
                  <Save className="mr-2 h-4 w-4" />
                  Save Availability
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

