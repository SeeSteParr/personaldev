import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight, Headphones, Users, Award, Store, Calendar } from "lucide-react"
import SubscriptionTiers from "@/components/subscription-tiers"
import { HeroSection } from "@/components/hero-section"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <HeroSection />

      <main className="flex-1">
        <section className="py-12 md:py-24 bg-slate-50">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                  Transform Your Mind, Transform Your Life
                </h2>
                <p className="max-w-[700px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed mx-auto">
                  Join our community of hypnotherapists and clients dedicated to personal growth and transformation.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mt-12">
              <div className="flex flex-col items-center space-y-4 p-6 bg-white rounded-lg shadow-md">
                <div className="p-3 bg-primary/10 rounded-full">
                  <Headphones className="w-10 h-10 text-primary" />
                </div>
                <h3 className="text-xl font-bold">Audio Library</h3>
                <p className="text-center text-gray-500">
                  Access our extensive library of hypnotherapy sessions and guided meditations.
                </p>
              </div>

              <div className="flex flex-col items-center space-y-4 p-6 bg-white rounded-lg shadow-md">
                <div className="p-3 bg-primary/10 rounded-full">
                  <Users className="w-10 h-10 text-primary" />
                </div>
                <h3 className="text-xl font-bold">Community</h3>
                <p className="text-center text-gray-500">
                  Connect with like-minded individuals and certified therapists.
                </p>
              </div>

              <div className="flex flex-col items-center space-y-4 p-6 bg-white rounded-lg shadow-md">
                <div className="p-3 bg-primary/10 rounded-full">
                  <Award className="w-10 h-10 text-primary" />
                </div>
                <h3 className="text-xl font-bold">Certification</h3>
                <p className="text-center text-gray-500">
                  Complete our courses and join the Guild of International Hypnotherapeutic Knights.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="py-12 md:py-24">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Membership Tiers</h2>
                <p className="max-w-[700px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed mx-auto">
                  Choose the membership tier that best suits your needs and goals.
                </p>
              </div>
            </div>

            <SubscriptionTiers />
          </div>
        </section>

        <section className="py-12 md:py-24 bg-slate-50">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Features</h2>
                <p className="max-w-[700px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed mx-auto">
                  Our platform offers a comprehensive suite of tools for both clients and therapists.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-12">
              <div className="flex items-start space-x-4">
                <div className="p-2 bg-primary/10 rounded-full">
                  <Store className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="text-xl font-bold">Store</h3>
                  <p className="text-gray-500">Browse and purchase hypnotherapy resources, courses, and tools.</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="p-2 bg-primary/10 rounded-full">
                  <Calendar className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="text-xl font-bold">Appointment Booking</h3>
                  <p className="text-gray-500">
                    Schedule sessions with certified therapists via Zoom or other platforms.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="p-2 bg-primary/10 rounded-full">
                  <Users className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="text-xl font-bold">Messaging</h3>
                  <p className="text-gray-500">
                    Connect directly with therapists and other members through our secure messaging system.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="p-2 bg-primary/10 rounded-full">
                  <Award className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="text-xl font-bold">Guild Membership</h3>
                  <p className="text-gray-500">Join the prestigious Guild of International Hypnotherapeutic Knights.</p>
                </div>
              </div>
            </div>

            <div className="flex justify-center mt-12">
              <Button asChild size="lg">
                <Link href="/register">
                  Get Started <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
        </section>
      </main>
    </div>
  )
}

